#ifndef HUFF0_H
#define HUFF0_H 
#if defined (__cplusplus)
extern "C" {
#endif
#include <stddef.h>
size_t HUF_compress(void* dst, size_t dstCapacity,
              const void* src, size_t srcSize);
size_t HUF_decompress(void* dst, size_t dstSize,
                const void* cSrc, size_t cSrcSize);
size_t HUF_compressBound(size_t size);
unsigned HUF_isError(size_t code);
const char* HUF_getErrorName(size_t code);
size_t HUF_compress2 (void* dst, size_t dstSize, const void* src, size_t srcSize, unsigned maxSymbolValue, unsigned tableLog);
#if defined (__cplusplus)
}
#endif
#endif
