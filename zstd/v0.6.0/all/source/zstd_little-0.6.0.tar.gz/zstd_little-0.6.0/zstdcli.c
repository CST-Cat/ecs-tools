#define _CRT_SECURE_NO_WARNINGS 
#define _POSIX_SOURCE 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fileio.h"
#ifndef ZSTD_NOBENCH
# include "bench.h"
#endif
#include "zstd_static.h"
#ifndef ZSTD_NODICT
# include "dibio.h"
#endif
#if defined(MSDOS) || defined(OS2) || defined(WIN32) || defined(_WIN32) || defined(__CYGWIN__)
# include <fcntl.h>
# include <io.h>
#define SET_BINARY_MODE(file) _setmode(_fileno(file), _O_BINARY)
#define IS_CONSOLE(stdStream) _isatty(_fileno(stdStream))
#else
# include <unistd.h>
#define SET_BINARY_MODE(file) 
#define IS_CONSOLE(stdStream) isatty(fileno(stdStream))
#endif
#define COMPRESSOR_NAME "zstd command line interface"
#ifndef ZSTD_VERSION
#define LIB_VERSION ZSTD_VERSION_MAJOR.ZSTD_VERSION_MINOR.ZSTD_VERSION_RELEASE
#define QUOTE(str) #str
#define EXPAND_AND_QUOTE(str) QUOTE(str)
#define ZSTD_VERSION "v" EXPAND_AND_QUOTE(LIB_VERSION)
#endif
#define AUTHOR "Yann Collet"
#define WELCOME_MESSAGE "*** %s %i-bits %s, by %s ***\n", COMPRESSOR_NAME, (int)(sizeof(void*)*8), ZSTD_VERSION, AUTHOR
#define ZSTD_EXTENSION ".zst"
#define ZSTD_CAT "zstdcat"
#define ZSTD_UNZSTD "unzstd"
#define KB *(1 <<10)
#define MB *(1 <<20)
#define GB *(1U<<30)
static const char* g_defaultDictName = "dictionary";
static const unsigned g_defaultMaxDictSize = 110 KB;
static const unsigned g_defaultDictCLevel = 5;
static const unsigned g_defaultSelectivityLevel = 9;
#define DISPLAY(...) fprintf(displayOut, __VA_ARGS__)
#define DISPLAYLEVEL(l,...) if (displayLevel>=l) { DISPLAY(__VA_ARGS__); }
static FILE* displayOut;
static unsigned displayLevel = 2;
static int usage(const char* programName)
{
    DISPLAY( "Usage :\n");
    DISPLAY( "      %s [args] [FILE(s)] [-o file]\n", programName);
    DISPLAY( "\n");
    DISPLAY( "FILE    : a filename\n");
    DISPLAY( "          with no FILE, or when FILE is - , read standard input\n");
    DISPLAY( "Arguments :\n");
    DISPLAY( " -#     : # compression level (1-%u, default:1) \n", ZSTD_maxCLevel());
    DISPLAY( " -d     : decompression \n");
    DISPLAY( " -D file: use `file` as Dictionary \n");
    DISPLAY( " -o file: result stored into `file` (only if 1 input file) \n");
    DISPLAY( " -f     : overwrite output without prompting \n");
    DISPLAY( " -h/-H  : display help/long help and exit\n");
    return 0;
}
static int usage_advanced(const char* programName)
{
    DISPLAY(WELCOME_MESSAGE);
    usage(programName);
    DISPLAY( "\n");
    DISPLAY( "Advanced arguments :\n");
    DISPLAY( " -V     : display Version number and exit\n");
    DISPLAY( " -t     : test compressed file integrity \n");
    DISPLAY( " -v     : verbose mode\n");
    DISPLAY( " -q     : suppress warnings; specify twice to suppress errors too\n");
    DISPLAY( " -c     : force write to standard output, even if it is the console\n");
    DISPLAY( "--ultra : enable ultra modes (requires more memory to decompress)\n");
#ifndef ZSTD_NODICT
    DISPLAY( "Dictionary builder :\n");
    DISPLAY( "--train : create a dictionary from a training set of files \n");
    DISPLAY( " -o file: `file` is dictionary name (default: %s) \n", g_defaultDictName);
    DISPLAY( "--maxdict:limit dictionary to specified size (default : %u) \n", g_defaultMaxDictSize);
    DISPLAY( " -s#    : dictionary selectivity level (default: %u)\n", g_defaultSelectivityLevel);
#endif
#ifndef ZSTD_NOBENCH
    DISPLAY( "Benchmark arguments :\n");
    DISPLAY( " -b#    : benchmark file(s), using # compression level (default : 1) \n");
    DISPLAY( " -r#    : test all compression levels from -bX to # (default: 1)\n");
    DISPLAY( " -i#    : iteration loops [1-9](default : 3)\n");
    DISPLAY( " -B#    : cut file into independent blocks of size # (default: no block)\n");
#endif
    return 0;
}
static int badusage(const char* programName)
{
    DISPLAYLEVEL(1, "Incorrect parameters\n");
    if (displayLevel >= 1) usage(programName);
    return 1;
}
static void waitEnter(void)
{
    int unused;
    DISPLAY("Press enter to continue...\n");
    unused = getchar();
    (void)unused;
}
#define CLEAN_RETURN(i) { operationResult = (i); goto _end; }
int main(int argCount, const char** argv)
{
    int i,
        bench=0,
        decode=0,
        forceStdout=0,
        main_pause=0,
        nextEntryIsDictionary=0,
        operationResult=0,
        dictBuild=0,
        nextArgumentIsOutFileName=0,
        nextArgumentIsMaxDict=0;
    unsigned cLevel = 1;
    unsigned cLevelLast = 1;
    const char** filenameTable = (const char**)malloc(argCount * sizeof(const char*));
    unsigned filenameIdx = 0;
    const char* programName = argv[0];
    const char* outFileName = NULL;
    const char* dictFileName = NULL;
    char* dynNameSpace = NULL;
    unsigned maxDictSize = g_defaultMaxDictSize;
    unsigned dictCLevel = g_defaultDictCLevel;
    unsigned dictSelect = g_defaultSelectivityLevel;
    (void)cLevelLast; (void)dictCLevel;
    if (filenameTable==NULL) { DISPLAY("not enough memory\n"); exit(1); }
    displayOut = stderr;
    for (i = (int)strlen(programName); i > 0; i--) { if (programName[i] == '/') { i++; break; } }
    programName += i;
    if (!strcmp(programName, ZSTD_UNZSTD)) decode=1;
    if (!strcmp(programName, ZSTD_CAT)) { decode=1; forceStdout=1; displayLevel=1; outFileName=stdoutmark; }
    for(i=1; i<argCount; i++) {
        const char* argument = argv[i];
        if(!argument) continue;
        if (!strcmp(argument, "--decompress")) { decode=1; continue; }
        if (!strcmp(argument, "--force")) { FIO_overwriteMode(); continue; }
        if (!strcmp(argument, "--version")) { displayOut=stdout; DISPLAY(WELCOME_MESSAGE); CLEAN_RETURN(0); }
        if (!strcmp(argument, "--help")) { displayOut=stdout; CLEAN_RETURN(usage_advanced(programName)); }
        if (!strcmp(argument, "--verbose")) { displayLevel=4; continue; }
        if (!strcmp(argument, "--quiet")) { displayLevel--; continue; }
        if (!strcmp(argument, "--stdout")) { forceStdout=1; outFileName=stdoutmark; displayLevel=1; continue; }
        if (!strcmp(argument, "--test")) { decode=1; outFileName=nulmark; FIO_overwriteMode(); continue; }
        if (!strcmp(argument, "--train")) { dictBuild=1; outFileName=g_defaultDictName; continue; }
        if (!strcmp(argument, "--maxdict")) { nextArgumentIsMaxDict=1; continue; }
        if (!strcmp(argument, "--keep")) { continue; }
        if (!strcmp(argument, "--ultra")) { FIO_setMaxWLog(0); continue; }
        if (!strcmp(argument, "-")){
            if (!filenameIdx) { filenameIdx=1, filenameTable[0]=stdinmark; outFileName=stdoutmark; continue; }
        }
        if (argument[0]=='-') {
            argument++;
            while (argument[0]!=0) {
                if ((*argument>='0') && (*argument<='9')) {
                    cLevel = 0;
                    while ((*argument >= '0') && (*argument <= '9')) {
                        cLevel *= 10;
                        cLevel += *argument - '0';
                        argument++;
                    }
                    dictCLevel = cLevel;
                    if (dictCLevel > ZSTD_maxCLevel())
                        CLEAN_RETURN(badusage(programName));
                    continue;
                }
                switch(argument[0])
                {
                case 'V': displayOut=stdout; DISPLAY(WELCOME_MESSAGE); CLEAN_RETURN(0);
                case 'H':
                case 'h': displayOut=stdout; CLEAN_RETURN(usage_advanced(programName));
                case 'd': decode=1; argument++; break;
                case 'c': forceStdout=1; outFileName=stdoutmark; displayLevel=1; argument++; break;
                case 'D': nextEntryIsDictionary = 1; argument++; break;
                case 'f': FIO_overwriteMode(); argument++; break;
                case 'v': displayLevel=4; argument++; break;
                case 'q': displayLevel--; argument++; break;
                case 'k': argument++; break;
                case 't': decode=1; outFileName=nulmark; FIO_overwriteMode(); argument++; break;
                case 'o': nextArgumentIsOutFileName=1; argument++; break;
#ifndef ZSTD_NOBENCH
                case 'b': bench=1; argument++; break;
                case 'i':
                    { U32 iters= 0;
                        argument++;
                        while ((*argument >='0') && (*argument <='9'))
                            iters *= 10, iters += *argument++ - '0';
                        BMK_setNotificationLevel(displayLevel);
                        BMK_SetNbIterations(iters);
                    }
                    break;
                case 'B':
                    { size_t bSize = 0;
                        argument++;
                        while ((*argument >='0') && (*argument <='9'))
                            bSize *= 10, bSize += *argument++ - '0';
                        if (*argument=='K') bSize<<=10, argument++;
                        if (*argument=='M') bSize<<=20, argument++;
                        if (*argument=='B') argument++;
                        BMK_setNotificationLevel(displayLevel);
                        BMK_SetBlockSize(bSize);
                    }
                    break;
                case 'r':
                        argument++;
                        if ((*argument>='0') && (*argument<='9')) {
                            cLevelLast = 0;
                            while ((*argument >= '0') && (*argument <= '9'))
                                cLevelLast *= 10, cLevelLast += *argument++ - '0';
                        }
                        break;
#endif
                case 's': argument++;
                    dictSelect = 0;
                    while ((*argument >= '0') && (*argument <= '9'))
                        dictSelect *= 10, dictSelect += *argument++ - '0';
                    break;
                case 'p': argument++;
#ifndef ZSTD_NOBENCH
                    if ((*argument>='0') && (*argument<='9')) {
                        int additionalParam = 0;
                        while ((*argument >= '0') && (*argument <= '9'))
                            additionalParam *= 10, additionalParam += *argument++ - '0';
                        BMK_setAdditionalParam(additionalParam);
                    } else
#endif
                        main_pause=1;
                    break;
                default : CLEAN_RETURN(badusage(programName));
                }
            }
            continue;
        }
        if (nextEntryIsDictionary) {
            nextEntryIsDictionary = 0;
            dictFileName = argument;
            continue;
        }
        if (nextArgumentIsOutFileName) {
            nextArgumentIsOutFileName = 0;
            outFileName = argument;
            if (!strcmp(outFileName, "-")) outFileName = stdoutmark;
            continue;
        }
        if (nextArgumentIsMaxDict) {
            nextArgumentIsMaxDict = 0;
            maxDictSize = 0;
            while ((*argument>='0') && (*argument<='9'))
                maxDictSize = maxDictSize * 10 + (*argument - '0'), argument++;
            if (*argument=='k' || *argument=='K')
                maxDictSize <<= 10;
            continue;
        }
        filenameTable[filenameIdx++] = argument;
    }
    DISPLAYLEVEL(3, WELCOME_MESSAGE);
    if (bench) {
#ifndef ZSTD_NOBENCH
        BMK_setNotificationLevel(displayLevel);
        BMK_benchFiles(filenameTable, filenameIdx, dictFileName, cLevel, cLevelLast);
#endif
        goto _end;
    }
    if (dictBuild) {
#ifndef ZSTD_NODICT
        ZDICT_params_t dictParams;
        dictParams.compressionLevel = dictCLevel;
        dictParams.selectivityLevel = dictSelect;
        dictParams.notificationLevel = displayLevel;
        DiB_trainFromFiles(outFileName, maxDictSize, filenameTable, filenameIdx, dictParams);
#endif
        goto _end;
    }
    if(!filenameIdx) filenameIdx=1, filenameTable[0]=stdinmark, outFileName=stdoutmark;
    if (!strcmp(filenameTable[0], stdinmark) && IS_CONSOLE(stdin) ) CLEAN_RETURN(badusage(programName));
    if (outFileName && !strcmp(outFileName, stdoutmark) && IS_CONSOLE(stdout) && !forceStdout) CLEAN_RETURN(badusage(programName));
    if (outFileName && strcmp(outFileName,stdoutmark) && strcmp(outFileName,nulmark) && (filenameIdx>1)) {
        DISPLAY("Too many files (%u) on the command line. \n", filenameIdx);
        CLEAN_RETURN(filenameIdx);
    }
    if (!strcmp(filenameTable[0], stdinmark) && outFileName && !strcmp(outFileName,stdoutmark) && (displayLevel==2)) displayLevel=1;
    if ((filenameIdx>1) && (displayLevel==2)) displayLevel=1;
    FIO_setNotificationLevel(displayLevel);
    if (decode) {
      if (filenameIdx==1 && outFileName)
        operationResult = FIO_decompressFilename(outFileName, filenameTable[0], dictFileName);
      else
        operationResult = FIO_decompressMultipleFilenames(filenameTable, filenameIdx, outFileName ? outFileName : ZSTD_EXTENSION, dictFileName);
    } else {
        if (filenameIdx==1 && outFileName)
          operationResult = FIO_compressFilename(outFileName, filenameTable[0], dictFileName, cLevel);
        else
          operationResult = FIO_compressMultipleFilenames(filenameTable, filenameIdx, outFileName ? outFileName : ZSTD_EXTENSION, dictFileName, cLevel);
    }
_end:
    if (main_pause) waitEnter();
    free(dynNameSpace);
    free((void*)filenameTable);
    return operationResult;
}
