#ifndef ERROR_H_MODULE
#define ERROR_H_MODULE 
#if defined (__cplusplus)
extern "C" {
#endif
#include <stddef.h>
#include "error_public.h"
#if defined(__GNUC__)
#define ERR_STATIC static __attribute__((unused))
#elif defined (__cplusplus) || (defined (__STDC_VERSION__) && (__STDC_VERSION__ >= 199901L) )
#define ERR_STATIC static inline
#elif defined(_MSC_VER)
#define ERR_STATIC static __inline
#else
#define ERR_STATIC static
#endif
typedef ZSTD_ErrorCode ERR_enum;
#define PREFIX(name) ZSTD_error_ ##name
#ifdef ERROR
#undef ERROR
#endif
#define ERROR(name) (size_t)-PREFIX(name)
ERR_STATIC unsigned ERR_isError(size_t code) { return (code > ERROR(maxCode)); }
ERR_STATIC ERR_enum ERR_getError(size_t code) { if (!ERR_isError(code)) return (ERR_enum)0; return (ERR_enum) (0-code); }
ERR_STATIC const char* ERR_getErrorName(size_t code)
{
    static const char* notErrorCode = "Unspecified error code";
    switch( ERR_getError(code) )
    {
    case PREFIX(no_error): return "No error detected";
    case PREFIX(GENERIC): return "Error (generic)";
    case PREFIX(prefix_unknown): return "Unknown frame descriptor";
    case PREFIX(frameParameter_unsupported): return "Unsupported frame parameter";
    case PREFIX(frameParameter_unsupportedBy32bits): return "Frame parameter unsupported in 32-bits mode";
    case PREFIX(init_missing): return "Context should be init first";
    case PREFIX(memory_allocation): return "Allocation error : not enough memory";
    case PREFIX(stage_wrong): return "Operation not authorized at current processing stage";
    case PREFIX(dstSize_tooSmall): return "Destination buffer is too small";
    case PREFIX(srcSize_wrong): return "Src size incorrect";
    case PREFIX(corruption_detected): return "Corrupted block detected";
    case PREFIX(tableLog_tooLarge): return "tableLog requires too much memory";
    case PREFIX(maxSymbolValue_tooLarge): return "Unsupported max possible Symbol Value : too large";
    case PREFIX(maxSymbolValue_tooSmall): return "Specified maxSymbolValue is too small";
    case PREFIX(dictionary_corrupted): return "Dictionary is corrupted";
    case PREFIX(maxCode):
    default: return notErrorCode;
    }
}
#if defined (__cplusplus)
}
#endif
#endif
