#ifndef ZSTD_BUFFERED_STATIC_H
#define ZSTD_BUFFERED_STATIC_H 
#if defined (__cplusplus)
extern "C" {
#endif
#include "zstd_static.h"
#include "zbuff.h"
ZSTDLIB_API size_t ZBUFF_compressInit_advanced(ZBUFF_CCtx* cctx, const void* dict, size_t dictSize, ZSTD_parameters params);
#if defined (__cplusplus)
}
#endif
#endif
