#ifndef ZSTD_H
#define ZSTD_H 
#if defined (__cplusplus)
extern "C" {
#endif
#include <stddef.h>
#if defined(_WIN32) && defined(ZSTD_DLL_EXPORT) && (ZSTD_DLL_EXPORT==1)
#define ZSTDLIB_API __declspec(dllexport)
#else
#define ZSTDLIB_API 
#endif
#define ZSTD_VERSION_MAJOR 0
#define ZSTD_VERSION_MINOR 4
#define ZSTD_VERSION_RELEASE 3
#define ZSTD_VERSION_NUMBER (ZSTD_VERSION_MAJOR *100*100 + ZSTD_VERSION_MINOR *100 + ZSTD_VERSION_RELEASE)
ZSTDLIB_API unsigned ZSTD_versionNumber (void);
ZSTDLIB_API size_t ZSTD_compress( void* dst, size_t maxDstSize,
                              const void* src, size_t srcSize,
                                     int compressionLevel);
ZSTDLIB_API size_t ZSTD_decompress( void* dst, size_t maxOriginalSize,
                              const void* src, size_t compressedSize);
ZSTDLIB_API size_t ZSTD_compressBound(size_t srcSize);
ZSTDLIB_API unsigned ZSTD_isError(size_t code);
ZSTDLIB_API const char* ZSTD_getErrorName(size_t code);
typedef struct ZSTD_CCtx_s ZSTD_CCtx;
ZSTDLIB_API ZSTD_CCtx* ZSTD_createCCtx(void);
ZSTDLIB_API size_t ZSTD_freeCCtx(ZSTD_CCtx* cctx);
ZSTDLIB_API size_t ZSTD_compressCCtx(ZSTD_CCtx* ctx, void* dst, size_t maxDstSize, const void* src, size_t srcSize, int compressionLevel);
#if defined (__cplusplus)
}
#endif
#endif
