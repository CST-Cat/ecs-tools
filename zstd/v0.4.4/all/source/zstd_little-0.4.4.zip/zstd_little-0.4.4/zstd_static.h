#ifndef ZSTD_STATIC_H
#define ZSTD_STATIC_H 
#if defined (__cplusplus)
extern "C" {
#endif
#include "zstd.h"
#include "mem.h"
#define ZSTD_WINDOWLOG_MAX 26
#define ZSTD_WINDOWLOG_MIN 18
#define ZSTD_WINDOWLOG_ABSOLUTEMIN 11
#define ZSTD_CONTENTLOG_MAX (ZSTD_WINDOWLOG_MAX+1)
#define ZSTD_CONTENTLOG_MIN 4
#define ZSTD_HASHLOG_MAX 28
#define ZSTD_HASHLOG_MIN 4
#define ZSTD_SEARCHLOG_MAX (ZSTD_CONTENTLOG_MAX-1)
#define ZSTD_SEARCHLOG_MIN 1
#define ZSTD_SEARCHLENGTH_MAX 7
#define ZSTD_SEARCHLENGTH_MIN 4
typedef enum { ZSTD_fast, ZSTD_greedy, ZSTD_lazy, ZSTD_lazy2, ZSTD_btlazy2 } ZSTD_strategy;
typedef struct
{
    U64 srcSize;
    U32 windowLog;
    U32 contentLog;
    U32 hashLog;
    U32 searchLog;
    U32 searchLength;
    ZSTD_strategy strategy;
} ZSTD_parameters;
ZSTDLIB_API ZSTD_parameters ZSTD_getParams(int compressionLevel, U64 srcSizeHint);
ZSTDLIB_API void ZSTD_validateParams(ZSTD_parameters* params);
ZSTDLIB_API size_t ZSTD_compress_advanced (ZSTD_CCtx* ctx,
                                           void* dst, size_t maxDstSize,
                                     const void* src, size_t srcSize,
                                           ZSTD_parameters params);
ZSTDLIB_API size_t ZSTD_compressBegin(ZSTD_CCtx* cctx, void* dst, size_t maxDstSize, int compressionLevel);
ZSTDLIB_API size_t ZSTD_compressBegin_advanced(ZSTD_CCtx* ctx, void* dst, size_t maxDstSize, ZSTD_parameters params);
ZSTDLIB_API size_t ZSTD_compress_insertDictionary(ZSTD_CCtx* ctx, const void* src, size_t srcSize);
ZSTDLIB_API size_t ZSTD_compressContinue(ZSTD_CCtx* cctx, void* dst, size_t maxDstSize, const void* src, size_t srcSize);
ZSTDLIB_API size_t ZSTD_compressEnd(ZSTD_CCtx* cctx, void* dst, size_t maxDstSize);
typedef struct ZSTD_DCtx_s ZSTD_DCtx;
ZSTDLIB_API ZSTD_DCtx* ZSTD_createDCtx(void);
ZSTDLIB_API size_t ZSTD_freeDCtx(ZSTD_DCtx* dctx);
ZSTDLIB_API size_t ZSTD_resetDCtx(ZSTD_DCtx* dctx);
ZSTDLIB_API size_t ZSTD_getFrameParams(ZSTD_parameters* params, const void* src, size_t srcSize);
ZSTDLIB_API void ZSTD_decompress_insertDictionary(ZSTD_DCtx* ctx, const void* src, size_t srcSize);
ZSTDLIB_API size_t ZSTD_nextSrcSizeToDecompress(ZSTD_DCtx* dctx);
ZSTDLIB_API size_t ZSTD_decompressContinue(ZSTD_DCtx* dctx, void* dst, size_t maxDstSize, const void* src, size_t srcSize);
#define ZSTD_MAX_CLEVEL 20
ZSTDLIB_API unsigned ZSTD_maxCLevel (void);
static const ZSTD_parameters ZSTD_defaultParameters[4][ZSTD_MAX_CLEVEL+1] = {
{
    { 0, 18, 12, 12, 1, 4, ZSTD_fast },
    { 0, 19, 13, 14, 1, 7, ZSTD_fast },
    { 0, 19, 15, 16, 1, 6, ZSTD_fast },
    { 0, 20, 18, 20, 1, 6, ZSTD_fast },
    { 0, 21, 19, 21, 1, 6, ZSTD_fast },
    { 0, 20, 14, 18, 3, 5, ZSTD_greedy },
    { 0, 20, 18, 19, 3, 5, ZSTD_greedy },
    { 0, 21, 17, 20, 3, 5, ZSTD_lazy },
    { 0, 21, 19, 20, 3, 5, ZSTD_lazy },
    { 0, 21, 20, 20, 3, 5, ZSTD_lazy2 },
    { 0, 21, 19, 21, 4, 5, ZSTD_lazy2 },
    { 0, 22, 20, 22, 4, 5, ZSTD_lazy2 },
    { 0, 22, 20, 22, 5, 5, ZSTD_lazy2 },
    { 0, 22, 21, 22, 5, 5, ZSTD_lazy2 },
    { 0, 22, 22, 23, 5, 5, ZSTD_lazy2 },
    { 0, 23, 23, 23, 5, 5, ZSTD_lazy2 },
    { 0, 23, 21, 22, 5, 5, ZSTD_btlazy2 },
    { 0, 23, 24, 23, 4, 5, ZSTD_btlazy2 },
    { 0, 25, 24, 23, 5, 5, ZSTD_btlazy2 },
    { 0, 25, 26, 23, 5, 5, ZSTD_btlazy2 },
    { 0, 26, 27, 25, 9, 5, ZSTD_btlazy2 },
},
{
    { 0, 0, 0, 0, 0, 0, ZSTD_fast },
    { 0, 18, 16, 15, 1, 7, ZSTD_fast },
    { 0, 18, 16, 16, 1, 7, ZSTD_fast },
    { 0, 18, 18, 18, 1, 7, ZSTD_fast },
    { 0, 18, 14, 15, 4, 6, ZSTD_greedy },
    { 0, 18, 16, 16, 1, 6, ZSTD_lazy },
    { 0, 18, 15, 15, 3, 6, ZSTD_lazy },
    { 0, 18, 15, 15, 4, 6, ZSTD_lazy },
    { 0, 18, 16, 18, 4, 6, ZSTD_lazy },
    { 0, 18, 18, 18, 4, 6, ZSTD_lazy },
    { 0, 18, 18, 18, 5, 6, ZSTD_lazy },
    { 0, 18, 18, 19, 6, 6, ZSTD_lazy },
    { 0, 18, 18, 19, 7, 6, ZSTD_lazy },
    { 0, 18, 19, 15, 7, 5, ZSTD_btlazy2 },
    { 0, 18, 19, 16, 8, 5, ZSTD_btlazy2 },
    { 0, 18, 19, 17, 9, 5, ZSTD_btlazy2 },
    { 0, 18, 19, 17, 10, 5, ZSTD_btlazy2 },
    { 0, 18, 19, 17, 11, 5, ZSTD_btlazy2 },
    { 0, 18, 19, 17, 12, 5, ZSTD_btlazy2 },
    { 0, 18, 19, 17, 13, 5, ZSTD_btlazy2 },
    { 0, 18, 19, 17, 14, 5, ZSTD_btlazy2 },
},
{
    { 0, 17, 12, 12, 1, 4, ZSTD_fast },
    { 0, 17, 12, 13, 1, 6, ZSTD_fast },
    { 0, 17, 15, 16, 1, 5, ZSTD_fast },
    { 0, 17, 16, 17, 1, 5, ZSTD_fast },
    { 0, 17, 13, 15, 2, 4, ZSTD_greedy },
    { 0, 17, 15, 17, 3, 4, ZSTD_greedy },
    { 0, 17, 14, 17, 3, 4, ZSTD_lazy },
    { 0, 17, 16, 17, 4, 4, ZSTD_lazy },
    { 0, 17, 16, 17, 4, 4, ZSTD_lazy2 },
    { 0, 17, 17, 16, 5, 4, ZSTD_lazy2 },
    { 0, 17, 17, 16, 6, 4, ZSTD_lazy2 },
    { 0, 17, 17, 16, 7, 4, ZSTD_lazy2 },
    { 0, 17, 17, 16, 8, 4, ZSTD_lazy2 },
    { 0, 17, 18, 16, 4, 4, ZSTD_btlazy2 },
    { 0, 17, 18, 16, 5, 4, ZSTD_btlazy2 },
    { 0, 17, 18, 16, 6, 4, ZSTD_btlazy2 },
    { 0, 17, 18, 16, 7, 4, ZSTD_btlazy2 },
    { 0, 17, 18, 16, 8, 4, ZSTD_btlazy2 },
    { 0, 17, 18, 16, 9, 4, ZSTD_btlazy2 },
    { 0, 17, 18, 16, 10, 4, ZSTD_btlazy2 },
    { 0, 17, 18, 18, 12, 4, ZSTD_btlazy2 },
},
{
    { 0, 0, 0, 0, 0, 0, ZSTD_fast },
    { 0, 14, 14, 14, 1, 4, ZSTD_fast },
    { 0, 14, 14, 16, 1, 4, ZSTD_fast },
    { 0, 14, 14, 14, 5, 4, ZSTD_greedy },
    { 0, 14, 14, 14, 8, 4, ZSTD_greedy },
    { 0, 14, 11, 14, 6, 4, ZSTD_lazy },
    { 0, 14, 14, 13, 6, 5, ZSTD_lazy },
    { 0, 14, 14, 14, 7, 6, ZSTD_lazy },
    { 0, 14, 14, 14, 8, 4, ZSTD_lazy },
    { 0, 14, 14, 15, 9, 4, ZSTD_lazy },
    { 0, 14, 14, 15, 10, 4, ZSTD_lazy },
    { 0, 14, 15, 15, 6, 4, ZSTD_btlazy2 },
    { 0, 14, 15, 15, 7, 4, ZSTD_btlazy2 },
    { 0, 14, 15, 15, 8, 4, ZSTD_btlazy2 },
    { 0, 14, 15, 15, 9, 4, ZSTD_btlazy2 },
    { 0, 14, 15, 15, 10, 4, ZSTD_btlazy2 },
    { 0, 14, 15, 15, 11, 4, ZSTD_btlazy2 },
    { 0, 14, 15, 15, 12, 4, ZSTD_btlazy2 },
    { 0, 14, 15, 15, 13, 4, ZSTD_btlazy2 },
    { 0, 14, 15, 15, 14, 4, ZSTD_btlazy2 },
    { 0, 14, 15, 15, 15, 4, ZSTD_btlazy2 },
},
};
#include "error.h"
#if defined (__cplusplus)
}
#endif
#endif
