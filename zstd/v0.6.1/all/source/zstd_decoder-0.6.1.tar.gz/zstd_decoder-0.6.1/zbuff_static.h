#ifndef ZSTD_BUFFERED_STATIC_H
#define ZSTD_BUFFERED_STATIC_H 
#if defined (__cplusplus)
extern "C" {
#endif
#include "zstd_static.h"
#include "zbuff.h"
#include "zstd_internal.h"
ZSTDLIB_API size_t ZBUFF_compressInit_advanced(ZBUFF_CCtx* cctx,
                                               const void* dict, size_t dictSize,
                                               ZSTD_parameters params, U64 pledgedSrcSize);
MEM_STATIC size_t ZBUFF_limitCopy(void* dst, size_t dstCapacity, const void* src, size_t srcSize)
{
    size_t length = MIN(dstCapacity, srcSize);
    memcpy(dst, src, length);
    return length;
}
#if defined (__cplusplus)
}
#endif
#endif
