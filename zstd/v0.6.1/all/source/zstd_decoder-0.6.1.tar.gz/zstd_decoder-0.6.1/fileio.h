       
#if defined (__cplusplus)
extern "C" {
#endif
#define nullString "null"
#define stdinmark "stdin"
#define stdoutmark "stdout"
#ifdef _WIN32
#define nulmark "nul"
#else
#define nulmark "/dev/null"
#endif
void FIO_overwriteMode(void);
void FIO_setNotificationLevel(unsigned level);
void FIO_setMaxWLog(unsigned maxWLog);
int FIO_compressFilename (const char* outfilename, const char* infilename, const char* dictFileName, int compressionLevel);
int FIO_decompressFilename (const char* outfilename, const char* infilename, const char* dictFileName);
int FIO_compressMultipleFilenames(const char** srcNamesTable, unsigned nbFiles,
                                  const char* suffix,
                                  const char* dictFileName, int compressionLevel);
int FIO_decompressMultipleFilenames(const char** srcNamesTable, unsigned nbFiles,
                                    const char* suffix,
                                    const char* dictFileName);
#if defined (__cplusplus)
}
#endif
