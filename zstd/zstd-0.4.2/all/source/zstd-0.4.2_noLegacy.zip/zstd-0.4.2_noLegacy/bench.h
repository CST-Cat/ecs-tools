       
int BMK_benchFiles(const char** fileNamesTable, unsigned nbFiles, unsigned cLevel);
void BMK_SetNbIterations(int nbLoops);
void BMK_SetBlockSize(size_t blockSize);
