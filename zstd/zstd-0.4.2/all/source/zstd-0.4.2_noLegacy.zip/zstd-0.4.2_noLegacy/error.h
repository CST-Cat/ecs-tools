#ifndef ERROR_H_MODULE
#define ERROR_H_MODULE 
#if defined (__cplusplus)
extern "C" {
#endif
#include <stddef.h>
#if defined (__cplusplus) || (defined (__STDC_VERSION__) && (__STDC_VERSION__ >= 199901L) )
#define ERR_STATIC static inline
#elif defined(_MSC_VER)
#define ERR_STATIC static __inline
#elif defined(__GNUC__)
#define ERR_STATIC static __attribute__((unused))
#else
#define ERR_STATIC static
#endif
#define PREFIX(name) ZSTD_error_ ##name
#define ERROR(name) (size_t)-PREFIX(name)
#define ERROR_LIST(ITEM) \
        ITEM(PREFIX(No_Error)) ITEM(PREFIX(GENERIC)) \
        ITEM(PREFIX(prefix_unknown)) ITEM(PREFIX(frameParameter_unsupported)) ITEM(PREFIX(frameParameter_unsupportedBy32bitsImplementation)) \
        ITEM(PREFIX(init_missing)) ITEM(PREFIX(memory_allocation)) \
        ITEM(PREFIX(dstSize_tooSmall)) ITEM(PREFIX(srcSize_wrong)) \
        ITEM(PREFIX(corruption_detected)) \
        ITEM(PREFIX(tableLog_tooLarge)) ITEM(PREFIX(maxSymbolValue_tooLarge)) ITEM(PREFIX(maxSymbolValue_tooSmall)) \
        ITEM(PREFIX(maxCode))
#define ERROR_GENERATE_ENUM(ENUM) ENUM,
typedef enum { ERROR_LIST(ERROR_GENERATE_ENUM) } ERR_codes;
#define ERROR_CONVERTTOSTRING(STRING) #STRING,
#define ERROR_GENERATE_STRING(EXPR) ERROR_CONVERTTOSTRING(EXPR)
static const char* ERR_strings[] = { ERROR_LIST(ERROR_GENERATE_STRING) };
ERR_STATIC unsigned ERR_isError(size_t code) { return (code > ERROR(maxCode)); }
ERR_STATIC const char* ERR_getErrorName(size_t code)
{
    static const char* codeError = "Unspecified error code";
    if (ERR_isError(code)) return ERR_strings[-(int)(code)];
    return codeError;
}
#if defined (__cplusplus)
}
#endif
#endif
