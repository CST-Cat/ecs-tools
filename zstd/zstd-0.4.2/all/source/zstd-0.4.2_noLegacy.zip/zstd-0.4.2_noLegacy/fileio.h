       
#if defined (__cplusplus)
extern "C" {
#endif
#define nullString "null"
#define stdinmark "-"
#define stdoutmark "-"
#ifdef _WIN32
#define nulmark "nul"
#else
#define nulmark "/dev/null"
#endif
void FIO_overwriteMode(void);
void FIO_setNotificationLevel(unsigned level);
unsigned long long FIO_compressFilename (const char* outfilename, const char* infilename, int compressionLevel);
unsigned long long FIO_decompressFilename (const char* outfilename, const char* infilename);
#if defined (__cplusplus)
}
#endif
