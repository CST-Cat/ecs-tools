#ifndef ZSTD_BUFFERED_H
#define ZSTD_BUFFERED_H 
#if defined (__cplusplus)
extern "C" {
#endif
#include <stddef.h>
typedef struct ZBUFF_CCtx_s ZBUFF_CCtx;
ZBUFF_CCtx* ZBUFF_createCCtx(void);
size_t ZBUFF_freeCCtx(ZBUFF_CCtx* cctx);
size_t ZBUFF_compressInit(ZBUFF_CCtx* cctx, int compressionLevel);
size_t ZBUFF_compressContinue(ZBUFF_CCtx* cctx, void* dst, size_t* maxDstSizePtr, const void* src, size_t* srcSizePtr);
size_t ZBUFF_compressFlush(ZBUFF_CCtx* cctx, void* dst, size_t* maxDstSizePtr);
size_t ZBUFF_compressEnd(ZBUFF_CCtx* cctx, void* dst, size_t* maxDstSizePtr);
typedef struct ZBUFF_DCtx_s ZBUFF_DCtx;
ZBUFF_DCtx* ZBUFF_createDCtx(void);
size_t ZBUFF_freeDCtx(ZBUFF_DCtx* dctx);
size_t ZBUFF_decompressInit(ZBUFF_DCtx* dctx);
size_t ZBUFF_decompressContinue(ZBUFF_DCtx* dctx, void* dst, size_t* maxDstSizePtr, const void* src, size_t* srcSizePtr);
unsigned ZBUFF_isError(size_t errorCode);
const char* ZBUFF_getErrorName(size_t errorCode);
size_t ZBUFF_recommendedCInSize(void);
size_t ZBUFF_recommendedCOutSize(void);
size_t ZBUFF_recommendedDInSize(void);
size_t ZBUFF_recommendedDOutSize(void);
#if defined (__cplusplus)
}
#endif
#endif
