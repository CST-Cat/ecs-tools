#ifndef ZSTD_BUFFERED_STATIC_H
#define ZSTD_BUFFERED_STATIC_H 
#if defined (__cplusplus)
extern "C" {
#endif
#include "zstd_static.h"
#include "zstd_buffered.h"
size_t ZBUFF_compressInit_advanced(ZBUFF_CCtx* cctx, ZSTD_parameters params);
#if defined (__cplusplus)
}
#endif
#endif
