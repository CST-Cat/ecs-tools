#define _CRT_SECURE_NO_WARNINGS 
#define _POSIX_SOURCE 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bench.h"
#include "fileio.h"
#if defined(MSDOS) || defined(OS2) || defined(WIN32) || defined(_WIN32) || defined(__CYGWIN__)
# include <fcntl.h>
# include <io.h>
# ifdef __MINGW32__
# endif
#define SET_BINARY_MODE(file) _setmode(_fileno(file), _O_BINARY)
#define IS_CONSOLE(stdStream) _isatty(_fileno(stdStream))
#else
# include <unistd.h>
#define SET_BINARY_MODE(file) 
#define IS_CONSOLE(stdStream) isatty(fileno(stdStream))
#endif
#define COMPRESSOR_NAME "zstd command line interface"
#ifndef ZSTD_VERSION
#define ZSTD_VERSION "v0.4.2"
#endif
#define AUTHOR "Yann Collet"
#define WELCOME_MESSAGE "*** %s %i-bits %s, by %s (%s) ***\n", COMPRESSOR_NAME, (int)(sizeof(void*)*8), ZSTD_VERSION, AUTHOR, __DATE__
#define ZSTD_EXTENSION ".zst"
#define ZSTD_CAT "zstdcat"
#define ZSTD_UNZSTD "unzstd"
#define KB *(1 <<10)
#define MB *(1 <<20)
#define GB *(1U<<30)
#define DISPLAY(...) fprintf(displayOut, __VA_ARGS__)
#define DISPLAYLEVEL(l,...) if (displayLevel>=l) { DISPLAY(__VA_ARGS__); }
static FILE* displayOut;
static unsigned displayLevel = 2;
#define DEBUG 0
#define DEBUGOUTPUT(...) if (DEBUG) DISPLAY(__VA_ARGS__);
#define EXM_THROW(error,...) \
{ \
    DEBUGOUTPUT("Error defined at %s, line %i : \n", __FILE__, __LINE__); \
    DISPLAYLEVEL(1, "Error %i : ", error); \
    DISPLAYLEVEL(1, __VA_ARGS__); \
    DISPLAYLEVEL(1, "\n"); \
    exit(error); \
}
static int usage(const char* programName)
{
    DISPLAY( "Usage :\n");
    DISPLAY( "      %s [arg] [input] [output]\n", programName);
    DISPLAY( "\n");
    DISPLAY( "input   : a filename\n");
    DISPLAY( "          with no FILE, or when FILE is - , read standard input\n");
    DISPLAY( "Arguments :\n");
    DISPLAY( " -1     : Fast compression (default) \n");
    DISPLAY( " -9     : High compression \n");
    DISPLAY( " -d     : decompression (default for %s extension)\n", ZSTD_EXTENSION);
    DISPLAY( " -f     : overwrite output without prompting \n");
    DISPLAY( " -h/-H  : display help/long help and exit\n");
    return 0;
}
static int usage_advanced(const char* programName)
{
    DISPLAY(WELCOME_MESSAGE);
    usage(programName);
    DISPLAY( "\n");
    DISPLAY( "Advanced arguments :\n");
    DISPLAY( " -V     : display Version number and exit\n");
    DISPLAY( " -v     : verbose mode\n");
    DISPLAY( " -q     : suppress warnings; specify twice to suppress errors too\n");
    DISPLAY( " -c     : force write to standard output, even if it is the console\n");
    DISPLAY( "Benchmark arguments :\n");
    DISPLAY( " -b#    : benchmark file(s), using # compression level (default : 1) \n");
    DISPLAY( " -B#    : cut file into independent blocks of size # (default : no block)\n");
    DISPLAY( " -i#    : iteration loops [1-9](default : 3)\n");
    DISPLAY( " -r#    : test all compression levels from 1 to # (default : disabled)\n");
    return 0;
}
static int badusage(const char* programName)
{
    DISPLAYLEVEL(1, "Incorrect parameters\n");
    if (displayLevel >= 1) usage(programName);
    return 1;
}
static void waitEnter(void)
{
    int unused;
    DISPLAY("Press enter to continue...\n");
    unused = getchar();
    (void)unused;
}
int main(int argCount, const char** argv)
{
    int i,
        bench=0,
        decode=0,
        forceStdout=0,
        main_pause=0,
        rangeBench = 1;
    unsigned fileNameStart = 0;
    unsigned nbFiles = 0;
    unsigned cLevel = 1;
    const char* programName = argv[0];
    const char* inFileName = NULL;
    const char* outFileName = NULL;
    char* dynNameSpace = NULL;
    const char extension[] = ZSTD_EXTENSION;
    displayOut = stderr;
    for (i = (int)strlen(programName); i > 0; i--) { if (programName[i] == '/') { i++; break; } }
    programName += i;
    if (!strcmp(programName, ZSTD_UNZSTD)) decode=1;
    if (!strcmp(programName, ZSTD_CAT)) { decode=1; forceStdout=1; displayLevel=1; outFileName=stdoutmark; }
    for(i=1; i<argCount; i++)
    {
        const char* argument = argv[i];
        if(!argument) continue;
        if (!strcmp(argument, "--version")) { displayOut=stdout; DISPLAY(WELCOME_MESSAGE); return 0; }
        if (!strcmp(argument, "--help")) { displayOut=stdout; return usage_advanced(programName); }
        if (!strcmp(argument, "--verbose")) { displayLevel=4; continue; }
        if (argument[0]=='-')
        {
            if (argument[1]==0)
            {
                if (!inFileName) inFileName=stdinmark;
                else outFileName=stdoutmark;
                continue;
            }
            argument++;
            while (argument[0]!=0)
            {
                if ((*argument>='0') && (*argument<='9'))
                {
                    cLevel = 0;
                    while ((*argument >= '0') && (*argument <= '9'))
                    {
                        cLevel *= 10;
                        cLevel += *argument - '0';
                        argument++;
                    }
                    continue;
                }
                switch(argument[0])
                {
                case 'V': displayOut=stdout; DISPLAY(WELCOME_MESSAGE); return 0;
                case 'H':
                case 'h': displayOut=stdout; return usage_advanced(programName);
                case 'd': decode=1; argument++; break;
                case 'c': forceStdout=1; outFileName=stdoutmark; displayLevel=1; argument++; break;
                case 'f': FIO_overwriteMode(); argument++; break;
                case 'v': displayLevel=4; argument++; break;
                case 'q': displayLevel--; argument++; break;
                case 'k': argument++; break;
                case 'b': bench=1; argument++; break;
                case 'i':
                    {
                        int iters= 0;
                        argument++;
                        while ((*argument >='0') && (*argument <='9'))
                            iters *= 10, iters += *argument++ - '0';
                        BMK_SetNbIterations(iters);
                    }
                    break;
                case 'B':
                    {
                        size_t bSize = 0;
                        argument++;
                        while ((*argument >='0') && (*argument <='9'))
                            bSize *= 10, bSize += *argument++ - '0';
                        if (*argument=='K') bSize<<=10, argument++;
                        if (*argument=='M') bSize<<=20, argument++;
                        if (*argument=='B') argument++;
                        BMK_SetBlockSize(bSize);
                    }
                    break;
                case 'r':
                        rangeBench = -1;
                        argument++;
                        break;
                case 'p': main_pause=1; argument++; break;
                default : return badusage(programName);
                }
            }
            continue;
        }
        if (!inFileName) { inFileName = argument; fileNameStart = i; nbFiles = argCount-i; continue; }
        if (!outFileName)
        {
            outFileName = argument;
            if (!strcmp (outFileName, nullString)) outFileName = nulmark;
            continue;
        }
    }
    DISPLAYLEVEL(3, WELCOME_MESSAGE);
    if (bench) { BMK_benchFiles(argv+fileNameStart, nbFiles, cLevel*rangeBench); goto _end; }
    if(!inFileName) { inFileName=stdinmark; }
    if (!strcmp(inFileName, stdinmark) && IS_CONSOLE(stdin) ) return badusage(programName);
    while (!outFileName)
    {
        if (!IS_CONSOLE(stdout)) { outFileName=stdoutmark; break; }
        if (!decode)
        {
            size_t l = strlen(inFileName);
            dynNameSpace = (char*)calloc(1,l+5);
            if (dynNameSpace==NULL) { DISPLAY("not enough memory\n"); exit(1); }
            strcpy(dynNameSpace, inFileName);
            strcpy(dynNameSpace+l, ZSTD_EXTENSION);
            outFileName = dynNameSpace;
            DISPLAYLEVEL(2, "Compressed filename will be : %s \n", outFileName);
            break;
        }
        {
            size_t filenameSize = strlen(inFileName);
            if (strcmp(inFileName + (filenameSize-4), extension))
            {
                 DISPLAYLEVEL(1, "unknown suffix - cannot determine destination filename\n");
                 return badusage(programName);
            }
            dynNameSpace = (char*)calloc(1,filenameSize+1);
            if (dynNameSpace==NULL) { DISPLAY("not enough memory\n"); exit(1); }
            outFileName = dynNameSpace;
            strcpy(dynNameSpace, inFileName);
            dynNameSpace[filenameSize-4]=0;
            DISPLAYLEVEL(2, "Decoding file %s \n", outFileName);
        }
    }
    if (!strcmp(outFileName,stdoutmark) && IS_CONSOLE(stdout) && !forceStdout) return badusage(programName);
    if (!strcmp(inFileName, stdinmark) && !strcmp(outFileName,stdoutmark) && (displayLevel==2)) displayLevel=1;
    FIO_setNotificationLevel(displayLevel);
    if (decode)
        FIO_decompressFilename(outFileName, inFileName);
    else
        FIO_compressFilename(outFileName, inFileName, cLevel);
_end:
    if (main_pause) waitEnter();
    free(dynNameSpace);
    return 0;
}
