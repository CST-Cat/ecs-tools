#define _CRT_SECURE_NO_WARNINGS 
#define _FILE_OFFSET_BITS 64
#if (defined(__sun__) && (!defined(__LP64__)))
#define _LARGEFILE_SOURCE 
#elif ! defined(__LP64__)
#define _LARGEFILE64_SOURCE 
#endif
#if defined(_MSC_VER) || defined(_WIN32)
#define BMK_LEGACY_TIMER 1
#endif
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#if defined(BMK_LEGACY_TIMER)
# include <sys/timeb.h>
#else
# include <sys/time.h>
#endif
#include "mem.h"
#include "zstd.h"
#include "xxhash.h"
#include "datagen.h"
#if !defined(S_ISREG)
#define S_ISREG(x) (((x) & S_IFMT) == S_IFREG)
#endif
#define NBLOOPS 3
#define TIMELOOP 2500
#define KB *(1 <<10)
#define MB *(1 <<20)
#define GB *(1U<<30)
static const size_t maxMemory = (sizeof(size_t)==4) ? (2 GB - 64 MB) : (size_t)(1ULL << ((sizeof(size_t)*8)-31));
#define DEFAULT_CHUNKSIZE (4 MB)
static U32 g_compressibilityDefault = 50;
#define DISPLAY(...) fprintf(stderr, __VA_ARGS__)
static int nbIterations = NBLOOPS;
static size_t g_blockSize = 0;
void BMK_SetNbIterations(int nbLoops)
{
    nbIterations = nbLoops;
    DISPLAY("- %i iterations -\n", nbIterations);
}
void BMK_SetBlockSize(size_t blockSize)
{
    g_blockSize = blockSize;
    DISPLAY("using blocks of size %u KB \n", (U32)(blockSize>>10));
}
#if defined(BMK_LEGACY_TIMER)
static int BMK_GetMilliStart(void)
{
  struct timeb tb;
  int nCount;
  ftime( &tb );
  nCount = (int) (tb.millitm + (tb.time & 0xfffff) * 1000);
  return nCount;
}
#else
static int BMK_GetMilliStart(void)
{
  struct timeval tv;
  int nCount;
  gettimeofday(&tv, NULL);
  nCount = (int) (tv.tv_usec/1000 + (tv.tv_sec & 0xfffff) * 1000);
  return nCount;
}
#endif
static int BMK_GetMilliSpan( int nTimeStart )
{
  int nSpan = BMK_GetMilliStart() - nTimeStart;
  if ( nSpan < 0 )
    nSpan += 0x100000 * 1000;
  return nSpan;
}
typedef struct
{
    char* srcPtr;
    size_t srcSize;
    char* cPtr;
    size_t cRoom;
    size_t cSize;
    char* resPtr;
    size_t resSize;
} blockParam_t;
typedef size_t (*compressor_t) (void* dst, size_t maxDstSize, const void* src, size_t srcSize, int compressionLevel);
#define MIN(a,b) ((a)<(b) ? (a) : (b))
static int BMK_benchMem(void* srcBuffer, size_t srcSize, const char* fileName, int cLevel)
{
    const size_t blockSize = (g_blockSize ? g_blockSize : srcSize) + (!srcSize);
    const U32 nbBlocks = (U32) ((srcSize + (blockSize-1)) / blockSize);
    blockParam_t* const blockTable = (blockParam_t*) malloc(nbBlocks * sizeof(blockParam_t));
    const size_t maxCompressedSize = (size_t)nbBlocks * ZSTD_compressBound(blockSize);
    void* const compressedBuffer = malloc(maxCompressedSize);
    void* const resultBuffer = malloc(srcSize);
    const compressor_t compressor = ZSTD_compress;
    U64 crcOrig;
    if (strlen(fileName)>16)
        fileName += strlen(fileName)-16;
    if (!compressedBuffer || !resultBuffer || !blockTable)
    {
        DISPLAY("\nError: not enough memory!\n");
        free(compressedBuffer);
        free(resultBuffer);
        free(blockTable);
        return 12;
    }
    crcOrig = XXH64(srcBuffer, srcSize, 0);
    {
        U32 i;
        size_t remaining = srcSize;
        char* srcPtr = (char*)srcBuffer;
        char* cPtr = (char*)compressedBuffer;
        char* resPtr = (char*)resultBuffer;
        for (i=0; i<nbBlocks; i++)
        {
            size_t thisBlockSize = MIN(remaining, blockSize);
            blockTable[i].srcPtr = srcPtr;
            blockTable[i].cPtr = cPtr;
            blockTable[i].resPtr = resPtr;
            blockTable[i].srcSize = thisBlockSize;
            blockTable[i].cRoom = ZSTD_compressBound(thisBlockSize);
            srcPtr += thisBlockSize;
            cPtr += blockTable[i].cRoom;
            resPtr += thisBlockSize;
            remaining -= thisBlockSize;
        }
    }
    RDG_genBuffer(compressedBuffer, maxCompressedSize, 0.10, 0.50, 1);
    {
        int loopNb;
        size_t cSize = 0;
        double fastestC = 100000000., fastestD = 100000000.;
        double ratio = 0.;
        U64 crcCheck = 0;
        DISPLAY("\r%79s\r", "");
        for (loopNb = 1; loopNb <= nbIterations; loopNb++)
        {
            int nbLoops;
            int milliTime;
            U32 blockNb;
            DISPLAY("%2i-%-17.17s :%10u ->\r", loopNb, fileName, (U32)srcSize);
            memset(compressedBuffer, 0xE5, maxCompressedSize);
            nbLoops = 0;
            milliTime = BMK_GetMilliStart();
            while (BMK_GetMilliStart() == milliTime);
            milliTime = BMK_GetMilliStart();
            while (BMK_GetMilliSpan(milliTime) < TIMELOOP)
            {
                for (blockNb=0; blockNb<nbBlocks; blockNb++)
                    blockTable[blockNb].cSize = compressor(blockTable[blockNb].cPtr, blockTable[blockNb].cRoom, blockTable[blockNb].srcPtr,blockTable[blockNb].srcSize, cLevel);
                nbLoops++;
            }
            milliTime = BMK_GetMilliSpan(milliTime);
            cSize = 0;
            for (blockNb=0; blockNb<nbBlocks; blockNb++)
                cSize += blockTable[blockNb].cSize;
            if ((double)milliTime < fastestC*nbLoops) fastestC = (double)milliTime / nbLoops;
            ratio = (double)srcSize / (double)cSize;
            DISPLAY("%2i-%-17.17s :%10i ->%10i (%5.3f),%6.1f MB/s\r", loopNb, fileName, (int)srcSize, (int)cSize, ratio, (double)srcSize / fastestC / 1000.);
#if 1
            memset(resultBuffer, 0xD6, srcSize);
            nbLoops = 0;
            milliTime = BMK_GetMilliStart();
            while (BMK_GetMilliStart() == milliTime);
            milliTime = BMK_GetMilliStart();
            for ( ; BMK_GetMilliSpan(milliTime) < TIMELOOP; nbLoops++)
            {
                for (blockNb=0; blockNb<nbBlocks; blockNb++)
                    blockTable[blockNb].resSize = ZSTD_decompress(blockTable[blockNb].resPtr, blockTable[blockNb].srcSize,
                                                                  blockTable[blockNb].cPtr, blockTable[blockNb].cSize);
            }
            milliTime = BMK_GetMilliSpan(milliTime);
            if ((double)milliTime < fastestD*nbLoops) fastestD = (double)milliTime / nbLoops;
            DISPLAY("%2i-%-17.17s :%10i ->%10i (%5.3f),%6.1f MB/s ,%6.1f MB/s\r", loopNb, fileName, (int)srcSize, (int)cSize, ratio, (double)srcSize / fastestC / 1000., (double)srcSize / fastestD / 1000.);
            crcCheck = XXH64(resultBuffer, srcSize, 0);
            if (crcOrig!=crcCheck)
            {
                unsigned u;
                unsigned eBlockSize = (unsigned)(MIN(65536*2, blockSize));
                DISPLAY("\n!!! WARNING !!! %14s : Invalid Checksum : %x != %x\n", fileName, (unsigned)crcOrig, (unsigned)crcCheck);
                for (u=0; u<srcSize; u++)
                {
                    if (((BYTE*)srcBuffer)[u] != ((BYTE*)resultBuffer)[u])
                    {
                        printf("Decoding error at pos %u (block %u, pos %u) \n", u, u / eBlockSize, u % eBlockSize);
                        break;
                    }
                }
                break;
            }
#endif
        }
        if (crcOrig == crcCheck)
            DISPLAY("%2i-%-17.17s :%10i ->%10i (%5.3f),%6.1f MB/s ,%6.1f MB/s \n", cLevel, fileName, (int)srcSize, (int)cSize, ratio, (double)srcSize / fastestC / 1000., (double)srcSize / fastestD / 1000.);
    }
    free(compressedBuffer);
    free(resultBuffer);
    return 0;
}
static U64 BMK_GetFileSize(const char* infilename)
{
    int r;
#if defined(_MSC_VER)
    struct _stat64 statbuf;
    r = _stat64(infilename, &statbuf);
#else
    struct stat statbuf;
    r = stat(infilename, &statbuf);
#endif
    if (r || !S_ISREG(statbuf.st_mode)) return 0;
    return (U64)statbuf.st_size;
}
static size_t BMK_findMaxMem(U64 requiredMem)
{
    size_t step = 64 MB;
    BYTE* testmem = NULL;
    requiredMem = (((requiredMem >> 26) + 1) << 26);
    requiredMem += 2 * step;
    if (requiredMem > maxMemory) requiredMem = maxMemory;
    while (!testmem)
    {
        requiredMem -= step;
        testmem = (BYTE*)malloc((size_t)requiredMem);
    }
    free(testmem);
    return (size_t)(requiredMem - step);
}
static int BMK_benchOneFile(const char* inFileName, int cLevel)
{
    FILE* inFile;
    U64 inFileSize;
    size_t benchedSize, readSize;
    void* srcBuffer;
    int result=0;
    inFile = fopen(inFileName, "rb");
    if (inFile == NULL)
    {
        DISPLAY("Pb opening %s\n", inFileName);
        return 11;
    }
    inFileSize = BMK_GetFileSize(inFileName);
    benchedSize = BMK_findMaxMem(inFileSize * 3) / 3;
    if ((U64)benchedSize > inFileSize) benchedSize = (size_t)inFileSize;
    if (benchedSize < inFileSize)
        DISPLAY("Not enough memory for '%s' full size; testing %i MB only...\n", inFileName, (int)(benchedSize >> 20));
    srcBuffer = malloc(benchedSize);
    if (!srcBuffer)
    {
        DISPLAY("\nError: not enough memory!\n");
        fclose(inFile);
        return 12;
    }
    DISPLAY("Loading %s...       \r", inFileName);
    readSize = fread(srcBuffer, 1, benchedSize, inFile);
    fclose(inFile);
    if (readSize != benchedSize)
    {
        DISPLAY("\nError: problem reading file '%s' !!    \n", inFileName);
        free(srcBuffer);
        return 13;
    }
    if (cLevel<0)
    {
        int l;
        for (l=1; l <= -cLevel; l++)
            result = BMK_benchMem(srcBuffer, benchedSize, inFileName, l);
    }
    else
        result = BMK_benchMem(srcBuffer, benchedSize, inFileName, cLevel);
    free(srcBuffer);
    DISPLAY("\n");
    return result;
}
static int BMK_syntheticTest(int cLevel, double compressibility)
{
    size_t benchedSize = 10000000;
    void* srcBuffer = malloc(benchedSize);
    int result=0;
    char name[20] = {0};
    if (!srcBuffer)
    {
        DISPLAY("\nError: not enough memory!\n");
        free(srcBuffer);
        return 12;
    }
    RDG_genBuffer(srcBuffer, benchedSize, compressibility, 0.0, 0);
#ifdef _MSC_VER
    sprintf_s(name, 20, "Synthetic %2u%%", (unsigned)(compressibility*100));
#else
    snprintf (name, 20, "Synthetic %2u%%", (unsigned)(compressibility*100));
#endif
    if (cLevel<0)
    {
        int l;
        for (l=1; l <= -cLevel; l++)
            result = BMK_benchMem(srcBuffer, benchedSize, name, l);
    }
    else
        result = BMK_benchMem(srcBuffer, benchedSize, name, cLevel);
    free(srcBuffer);
    DISPLAY("\n");
    return result;
}
int BMK_benchFiles(const char** fileNamesTable, unsigned nbFiles, unsigned cLevel)
{
    double compressibility = (double)g_compressibilityDefault / 100;
    if (nbFiles == 0)
    {
        BMK_syntheticTest(cLevel, compressibility);
    }
    else
    {
        unsigned fileIdx = 0;
        while (fileIdx<nbFiles)
        {
            BMK_benchOneFile(fileNamesTable[fileIdx], cLevel);
            fileIdx++;
        }
    }
    return 0;
}
