package trace

import (
	"context"
	"fmt"
	"math/rand"
	"net"
	"os"
	"sync"
	"sync/atomic"
	"time"

	"github.com/google/gopacket/layers"

	"github.com/nxtrace/NTrace-core/trace/internal"
	"github.com/nxtrace/NTrace-core/util"
)

// ---------------------------------------------------------------------------
// MTR 长驻运行器
// ---------------------------------------------------------------------------

// MTROptions 控制 MTR 连续探测行为。
type MTROptions struct {
	// Interval 每轮之间的等待间隔（默认 1s）。
	// 仅在 legacy round-based 模式（Web MTR）使用。
	Interval time.Duration
	// MaxRounds 最大轮次，0 表示无限运行直到取消。
	// 仅在 legacy round-based 模式使用。
	MaxRounds int
	// HopInterval 同一 TTL 两次探测之间的间隔（per-hop 调度模式）。
	// > 0 时启用 per-hop 调度，忽略 Interval / MaxRounds。
	HopInterval time.Duration
	// MaxPerHop 每个 TTL 最大探测次数，0 表示无限。
	MaxPerHop int
	// IsPaused 可选：返回 true 时暂停探测（轮询检查）。
	IsPaused func() bool
	// IsResetRequested 可选：返回 true（原子消费）时重置统计。
	IsResetRequested func() bool
	// ProgressThrottle 流式预览最小刷新间隔（默认 200ms）。
	ProgressThrottle time.Duration
	// AsyncMetadata causes interactive per-hop MTR to render bare hops first,
	// then patch Geo/RDNS metadata into existing rows asynchronously.
	AsyncMetadata bool
}

// MTROnSnapshot 每轮完成后的回调，用于刷新 CLI 表格。
// iteration 是当前轮次（从 1 开始），stats 是截至当前的聚合快照。
type MTROnSnapshot func(iteration int, stats []MTRHopStat)

// mtrBackoffCfg 控制连续错误时的指数退避行为。
type mtrBackoffCfg struct {
	Initial   time.Duration
	Max       time.Duration
	MaxConsec int
}

var defaultBackoff = mtrBackoffCfg{
	Initial:   500 * time.Millisecond,
	Max:       30 * time.Second,
	MaxConsec: 10,
}

// mtrProber 抽象一轮探测，允许测试注入 mock。
type mtrProber interface {
	probeRound(ctx context.Context) (*Result, error)
	close()
}

// mtrResetter 可选接口：重置统计时清除 prober 内部缓存。
type mtrResetter interface {
	resetFinalTTL()
}

// mtrPeeker 可选接口：支持流式预览探测进度。
// 引擎在 probeRound 执行期间，外部可调用 peekPartialResult 获取当前已收到的部分响应。
type mtrPeeker interface {
	peekPartialResult() *Result
}

// RunMTR 启动 MTR 连续探测模式。
//
// 当 opts.HopInterval > 0 时使用 per-hop 独立调度（CLI MTR 模式）：
//
//	每个 TTL 独立计时，完成后等 HopInterval 再发下一个。
//
// 当 opts.HopInterval == 0 时使用 legacy round-based 调度（Web MTR 兼容）：
//
//	ICMP 使用持久 raw socket 跨轮复用；TCP/UDP 以 per-round Traceroute 回退。
func RunMTR(ctx context.Context, method Method, baseConfig Config, opts MTROptions, onSnapshot MTROnSnapshot) error {
	if opts.HopInterval > 0 {
		return runMTRPerHop(ctx, method, baseConfig, opts, onSnapshot)
	}
	return runMTRRoundBased(ctx, method, baseConfig, opts, onSnapshot)
}

// runMTRPerHop 使用 per-hop 独立调度模式。
func runMTRPerHop(ctx context.Context, method Method, baseConfig Config, opts MTROptions, onSnapshot MTROnSnapshot) error {
	normalizeRuntimeConfig(&baseConfig)
	baseConfig.NumMeasurements = 1
	baseConfig.MaxAttempts = 1
	baseConfig.RealtimePrinter = nil
	baseConfig.AsyncPrinter = nil

	if baseConfig.MaxHops == 0 {
		baseConfig.MaxHops = 30
	}
	if baseConfig.ICMPMode <= 0 && util.EnvICMPMode > 0 {
		baseConfig.ICMPMode = util.EnvICMPMode
	}
	switch baseConfig.ICMPMode {
	case 0, 1, 2:
	default:
		baseConfig.ICMPMode = 0
	}

	agg := NewMTRAggregator()
	var prober mtrTTLProber

	if method == ICMPTrace {
		engine, err := newMTRICMPEngine(baseConfig)
		if err != nil {
			return fmt.Errorf("mtr: %w", err)
		}
		defer engine.close()
		if err := engine.start(ctx); err != nil {
			engine.close()
			return fmt.Errorf("mtr: %w", err)
		}
		prober = engine
	} else {
		prober = &mtrFallbackTTLProber{method: method, config: baseConfig, asyncMetadata: opts.AsyncMetadata}
	}

	return runMTRScheduler(ctx, prober, agg, mtrSchedulerConfig{
		BeginHop:         baseConfig.BeginHop,
		MaxHops:          baseConfig.MaxHops,
		HopInterval:      opts.HopInterval,
		Timeout:          baseConfig.Timeout,
		MaxPerHop:        opts.MaxPerHop,
		ParallelRequests: baseConfig.ParallelRequests,
		ProgressThrottle: opts.ProgressThrottle,
		FillGeo:          true,
		AsyncMetadata:    opts.AsyncMetadata,
		BaseConfig:       baseConfig,
		DstIP:            baseConfig.DstIP,
		IsPaused:         opts.IsPaused,
		IsResetRequested: opts.IsResetRequested,
	}, onSnapshot, nil)
}

// runMTRRoundBased 使用 legacy round-based 调度模式（Web MTR 兼容）。
func runMTRRoundBased(ctx context.Context, method Method, baseConfig Config, opts MTROptions, onSnapshot MTROnSnapshot) error {
	normalizeRuntimeConfig(&baseConfig)
	if opts.Interval <= 0 {
		opts.Interval = time.Second
	}

	// MTR：每轮每 hop 仅一个探测包
	baseConfig.NumMeasurements = 1
	baseConfig.MaxAttempts = 1
	// 注意：不覆盖 ParallelRequests——尊重用户 --parallel-requests 设定
	baseConfig.RealtimePrinter = nil
	baseConfig.AsyncPrinter = nil

	// 与 Traceroute() 保持一致的默认值
	if baseConfig.MaxHops == 0 {
		baseConfig.MaxHops = 30
	}
	if baseConfig.ICMPMode <= 0 && util.EnvICMPMode > 0 {
		baseConfig.ICMPMode = util.EnvICMPMode
	}
	switch baseConfig.ICMPMode {
	case 0, 1, 2:
	default:
		baseConfig.ICMPMode = 0
	}

	agg := NewMTRAggregator()

	if method == ICMPTrace {
		engine, err := newMTRICMPEngine(baseConfig)
		if err != nil {
			return fmt.Errorf("mtr: %w", err)
		}
		defer engine.close()
		if err := engine.start(ctx); err != nil {
			engine.close()
			return fmt.Errorf("mtr: %w", err)
		}
		return mtrLoop(ctx, engine, baseConfig, opts, agg, onSnapshot, true, nil)
	}

	prober := &mtrFallbackProber{method: method, config: baseConfig}
	// Traceroute 内部已做 geo/rdns 查询，无需再填充
	return mtrLoop(ctx, prober, baseConfig, opts, agg, onSnapshot, false, nil)
}

// ---------------------------------------------------------------------------
// 主循环（ICMP 持久引擎 / TCP·UDP 回退共用）
// ---------------------------------------------------------------------------

func mtrLoop(
	ctx context.Context,
	prober mtrProber,
	config Config,
	opts MTROptions,
	agg *MTRAggregator,
	onSnapshot MTROnSnapshot,
	fillGeo bool,
	bo *mtrBackoffCfg,
) error {
	defer prober.close()
	rt := newMTRLoopRuntime(ctx, prober, config, opts, agg, onSnapshot, fillGeo, bo)
	return rt.run()
}

// mtrFillGeoRDNS 并发查询 Result 中各 hop 的地理信息与反向 DNS。
// fetchIPData 内部有 singleflight + geoCache，重复 IP 不会重复查询。
func mtrFillGeoRDNS(res *Result, config Config) {
	var wg sync.WaitGroup
	for idx := range res.Hops {
		for j := range res.Hops[idx] {
			h := &res.Hops[idx][j]
			if !h.Success || h.Address == nil {
				continue
			}
			h.Lang = config.Lang
			wg.Add(1)
			go func(hop *Hop) {
				defer wg.Done()
				_ = hop.fetchIPData(config)
			}(h)
		}
	}
	wg.Wait()
}

// ---------------------------------------------------------------------------
// 持久 ICMP 引擎（mtr 风格：raw socket 只创建一次，跨轮复用）
// ---------------------------------------------------------------------------

type mtrICMPEngine struct {
	config Config
	spec   *internal.ICMPSpec
	echoID int
	srcIP  net.IP
	ipVer  int

	// 单调递增序列号，避免跨轮 seq 冲突
	seqCounter uint32

	// per-round 探针/响应匹配
	mu       sync.Mutex
	sentAt   map[int]mtrProbeMeta // seq → probe metadata
	replied  map[int]*mtrProbeReply
	notifyCh chan struct{}

	// 当前轮次 ID，用于丢弃过期响应
	roundID uint32

	// 已知目的地 TTL（-1 = 未知），跨轮保留以减少无效探测
	knownFinalTTL int32
	// 当前轮次内发现的目的地 TTL（-1 = 本轮未发现）
	roundFinalTTL int32

	// 流式预览状态（peekPartialResult 使用，受 mu 保护）
	curTtlSeq       map[int]int
	curBeginHop     int
	curEffectiveMax int

	// Per-probe notification channels for ProbeTTL（受 mu 保护）。
	probeNotify map[int]chan struct{} // seq → done chan

	// sendMu serializes seq allocation + rotation check in concurrent ProbeTTL calls.
	sendMu sync.Mutex
}

// mtrProbeMeta 记录已发送探针的元信息，用于响应匹配。
type mtrProbeMeta struct {
	ttl     int
	start   time.Time
	roundID uint32
}

type mtrProbeReply struct {
	peer net.Addr
	rtt  time.Duration
	mpls []string
}

func newMTRICMPEngine(config Config) (*mtrICMPEngine, error) {
	ipVer := 4
	if config.DstIP.To4() == nil {
		ipVer = 6
	}

	var srcAddr net.IP
	if config.SrcAddr != "" {
		srcAddr = net.ParseIP(config.SrcAddr)
		if ipVer == 4 && srcAddr != nil {
			srcAddr = srcAddr.To4()
		}
	}

	var srcIP net.IP
	if ipVer == 6 {
		srcIP, _ = util.LocalIPPortv6(config.DstIP, srcAddr, "icmp6")
	} else {
		srcIP, _ = util.LocalIPPort(config.DstIP, srcAddr, "icmp")
	}
	if srcIP == nil {
		return nil, fmt.Errorf("cannot determine local IP for MTR ICMP")
	}

	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	echoID := (r.Intn(256) << 8) | (os.Getpid() & 0xFF)

	return &mtrICMPEngine{
		config:        config,
		ipVer:         ipVer,
		echoID:        echoID,
		srcIP:         srcIP,
		knownFinalTTL: -1,
	}, nil
}

// start 创建持久 ICMP 套接字及监听协程。ctx 生命周期控制整个引擎。
func (e *mtrICMPEngine) start(ctx context.Context) error {
	e.spec = internal.NewICMPSpec(e.ipVer, e.config.ICMPMode, e.echoID, e.srcIP, e.config.DstIP)
	applyICMPSourceDevice(e.spec, e.config.OSType, e.config.SourceDevice)
	e.spec.InitICMP()

	e.notifyCh = make(chan struct{}, 1)
	e.sentAt = make(map[int]mtrProbeMeta)
	e.replied = make(map[int]*mtrProbeReply)
	e.probeNotify = make(map[int]chan struct{})

	ready := make(chan struct{})
	go e.spec.ListenICMP(ctx, ready, e.onICMP)

	select {
	case <-ready:
	case <-ctx.Done():
		e.close()
		return ctx.Err()
	case <-time.After(5 * time.Second):
		e.close()
		return fmt.Errorf("ICMP listener startup timeout")
	}
	time.Sleep(100 * time.Millisecond)
	return nil
}

func (e *mtrICMPEngine) close() {
	if e.spec != nil {
		e.spec.Close()
		e.spec = nil
	}
}

// resetFinalTTL 清除已知目的地 TTL 缓存（r 键重置统计时调用）。
func (e *mtrICMPEngine) resetFinalTTL() {
	atomic.StoreInt32(&e.knownFinalTTL, -1)
}

// peekPartialResult 返回当前轮次已收到的部分探测结果（用于流式预览）。
// 在 probeRound 运行期间由外部 ticker 调用，与 probeRound 共享 mu 保护。
func (e *mtrICMPEngine) peekPartialResult() *Result {
	e.mu.Lock()
	defer e.mu.Unlock()

	beginHop := e.curBeginHop
	effectiveMax := e.curEffectiveMax
	if effectiveMax <= 0 || e.curTtlSeq == nil {
		return nil
	}

	// 若已检测到目的地，缩小预览范围
	if rf := atomic.LoadInt32(&e.roundFinalTTL); rf > 0 && int(rf) < effectiveMax {
		effectiveMax = int(rf)
	}

	res := &Result{Hops: make([][]Hop, effectiveMax)}
	for ttl := beginHop; ttl <= effectiveMax; ttl++ {
		idx := ttl - 1
		seq, sent := e.curTtlSeq[ttl]
		if !sent {
			// 尚未发送，保持 nil 槽位让聚合器跳过
			continue
		}
		if reply, ok := e.replied[seq]; ok {
			res.Hops[idx] = []Hop{{
				Success: true,
				Address: reply.peer,
				TTL:     ttl,
				RTT:     reply.rtt,
				MPLS:    reply.mpls,
			}}
		} else {
			// 已发送但未收到响应，显示为超时
			res.Hops[idx] = []Hop{{
				Success: false,
				Address: nil,
				TTL:     ttl,
				RTT:     0,
			}}
		}
	}
	return res
}

// seqWillWrap 判断再发 probeCount 个探针后 16 位 wire seq 是否会回卷。
// probeCount <= 0 时不发包，不可能回卷。
func seqWillWrap(seqCounter uint32, probeCount int) bool {
	if probeCount <= 0 {
		return false
	}
	return (seqCounter&0xFFFF)+uint32(probeCount) > 0xFFFF
}

// rotateEngine 关闭旧 ICMP 监听器，生成新 echoID 并重建引擎。
// 新 listener 过滤新 echoID，旧 echoID 的迟到回包在协议层即被丢弃，
// 从而彻底消除 seq 16 位回卷导致的跨轮误匹配。
func (e *mtrICMPEngine) rotateEngine(ctx context.Context) error {
	e.spec.Close()

	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	e.echoID = (r.Intn(256) << 8) | (os.Getpid() & 0xFF)
	atomic.StoreUint32(&e.seqCounter, 0)

	e.spec = internal.NewICMPSpec(e.ipVer, e.config.ICMPMode, e.echoID, e.srcIP, e.config.DstIP)
	applyICMPSourceDevice(e.spec, e.config.OSType, e.config.SourceDevice)
	e.spec.InitICMP()

	e.mu.Lock()
	// Notify any ProbeTTL waiters about rotation (they'll see no reply)
	for seq, ch := range e.probeNotify {
		close(ch)
		delete(e.probeNotify, seq)
	}
	e.notifyCh = make(chan struct{}, 1)
	e.sentAt = make(map[int]mtrProbeMeta)
	e.replied = make(map[int]*mtrProbeReply)
	e.probeNotify = make(map[int]chan struct{})
	e.mu.Unlock()

	ready := make(chan struct{})
	go e.spec.ListenICMP(ctx, ready, e.onICMP)

	select {
	case <-ready:
	case <-ctx.Done():
		e.close()
		return ctx.Err()
	case <-time.After(5 * time.Second):
		e.close()
		return fmt.Errorf("ICMP listener restart timeout on echoID rotation")
	}
	return nil
}

// onICMP 是 ListenICMP 的回调：将响应匹配到已发送的探针。
func (e *mtrICMPEngine) onICMP(msg internal.ReceivedMessage, finish time.Time, seq int) {
	e.mu.Lock()
	start, ok := e.sentAt[seq]
	if !ok {
		e.mu.Unlock()
		return
	}
	if e.shouldDiscardProbeReplyLocked(seq, start, finish) {
		e.mu.Unlock()
		return
	}

	rtt := finish.Sub(start.start)
	e.storeProbeReplyLocked(seq, msg, rtt)
	finalTTL := e.detectRoundFinalTTLCandidate(msg.Peer, start.ttl)
	e.mu.Unlock()

	e.updateRoundFinalTTL(finalTTL)
	e.signalReplyReady()
}

func (e *mtrICMPEngine) shouldDiscardProbeReplyLocked(seq int, start mtrProbeMeta, finish time.Time) bool {
	if start.roundID != atomic.LoadUint32(&e.roundID) {
		e.discardProbeLocked(seq)
		return true
	}
	if !e.validProbeRTT(finish.Sub(start.start)) {
		e.discardProbeLocked(seq)
		return true
	}
	return false
}

func (e *mtrICMPEngine) validProbeRTT(rtt time.Duration) bool {
	maxRTT := e.config.Timeout
	if maxRTT <= 0 {
		maxRTT = 2 * time.Second
	}
	return rtt > 0 && rtt <= maxRTT
}

func (e *mtrICMPEngine) discardProbeLocked(seq int) {
	delete(e.sentAt, seq)
	e.closeProbeNotifyLocked(seq)
}

func (e *mtrICMPEngine) storeProbeReplyLocked(seq int, msg internal.ReceivedMessage, rtt time.Duration) {
	e.replied[seq] = &mtrProbeReply{
		peer: msg.Peer,
		rtt:  rtt,
		mpls: extractMPLS(msg, e.config.DisableMPLS),
	}
	delete(e.sentAt, seq)
	e.closeProbeNotifyLocked(seq)
}

func (e *mtrICMPEngine) closeProbeNotifyLocked(seq int) {
	if ch, ok := e.probeNotify[seq]; ok {
		close(ch)
		delete(e.probeNotify, seq)
	}
}

func (e *mtrICMPEngine) detectRoundFinalTTLCandidate(peer net.Addr, ttl int) int32 {
	peerIP := mtrPeerIP(peer)
	if peerIP == nil || !peerIP.Equal(e.config.DstIP) {
		return -1
	}
	return int32(ttl)
}

func mtrPeerIP(addr net.Addr) net.IP {
	switch a := addr.(type) {
	case *net.IPAddr:
		return a.IP
	case *net.UDPAddr:
		return a.IP
	case *net.TCPAddr:
		return a.IP
	default:
		return nil
	}
}

func (e *mtrICMPEngine) updateRoundFinalTTL(ttl int32) {
	if ttl < 0 {
		return
	}
	curFinal := atomic.LoadInt32(&e.roundFinalTTL)
	if curFinal < 0 || ttl < curFinal {
		atomic.StoreInt32(&e.roundFinalTTL, ttl)
	}
}

func (e *mtrICMPEngine) signalReplyReady() {
	select {
	case e.notifyCh <- struct{}{}:
	default:
	}
}

// sendProbe 发送一个 ICMP echo（IPv4 或 IPv6），返回发送时间戳。
func (e *mtrICMPEngine) sendProbe(ctx context.Context, ttl, seq int) (time.Time, error) {
	payloadSize := resolveProbePayloadSize(ICMPTrace, e.config.DstIP, e.config.PktSize, e.config.RandomPacketSize)
	payload := make([]byte, payloadSize)
	if len(payload) >= 3 {
		copy(payload[len(payload)-3:], []byte{'n', 't', 'r'})
	}

	if e.ipVer == 4 {
		ipHdr := &layers.IPv4{
			Version:  4,
			SrcIP:    e.srcIP,
			DstIP:    e.config.DstIP,
			Protocol: layers.IPProtocolICMPv4,
			TTL:      uint8(ttl),
			TOS:      uint8(e.config.TOS),
		}
		icmpHdr := &layers.ICMPv4{
			TypeCode: layers.CreateICMPv4TypeCode(layers.ICMPv4TypeEchoRequest, 0),
			Id:       uint16(e.echoID),
			Seq:      uint16(seq),
		}
		return e.spec.SendICMP(ctx, ipHdr, icmpHdr, nil, payload)
	}

	// IPv6
	ipHdr := &layers.IPv6{
		Version:      6,
		SrcIP:        e.srcIP,
		DstIP:        e.config.DstIP,
		NextHeader:   layers.IPProtocolICMPv6,
		HopLimit:     uint8(ttl),
		TrafficClass: uint8(e.config.TOS),
	}
	icmpHdr := &layers.ICMPv6{
		TypeCode: layers.CreateICMPv6TypeCode(layers.ICMPv6TypeEchoRequest, 0),
	}
	if err := icmpHdr.SetNetworkLayerForChecksum(ipHdr); err != nil {
		return time.Time{}, fmt.Errorf("SetNetworkLayerForChecksum: %w", err)
	}
	icmpEcho := &layers.ICMPv6Echo{
		Identifier: uint16(e.echoID),
		SeqNumber:  uint16(seq),
	}
	return e.spec.SendICMP(ctx, ipHdr, icmpHdr, icmpEcho, payload)
}

// probeRound 执行一轮持久探测：对每个 TTL 发送一个 ICMP echo，
// 收集响应后构造与 Traceroute 兼容的 *Result。
// 若已知目的地 TTL 则提前停止发送。
func (e *mtrICMPEngine) probeRound(ctx context.Context) (*Result, error) {
	round := e.prepareProbeRound(ctx)
	if round.err != nil {
		return nil, round.err
	}
	if err := e.sendProbeSweep(ctx, round); err != nil {
		return nil, err
	}
	e.waitForProbeReplies(ctx)
	return e.buildProbeRoundResult(round.beginHop, e.finalizeProbeRound(round.effectiveMax)), nil
}

type mtrProbeRoundState struct {
	beginHop     int
	effectiveMax int
	roundID      uint32
	probeDelay   time.Duration
	err          error
}

func (e *mtrICMPEngine) prepareProbeRound(ctx context.Context) mtrProbeRoundState {
	maxHops := e.config.MaxHops
	beginHop := e.config.BeginHop
	if beginHop <= 0 {
		beginHop = 1
	}
	curRound := atomic.AddUint32(&e.roundID, 1)
	atomic.StoreInt32(&e.roundFinalTTL, -1)
	e.resetProbeRoundMaps()
	e.drainNotifySignal()

	probeCount := maxHops - beginHop + 1
	if probeCount < 1 {
		probeCount = 1
	}
	if err := e.rotateProbeEngineIfNeeded(ctx, probeCount); err != nil {
		return mtrProbeRoundState{err: fmt.Errorf("echoID rotation: %w", err)}
	}

	effectiveMax := e.effectiveProbeRoundMax(maxHops)
	e.initProbeRoundPreview(beginHop, effectiveMax)

	return mtrProbeRoundState{
		beginHop:     beginHop,
		effectiveMax: effectiveMax,
		roundID:      curRound,
		probeDelay:   e.probeRoundDelay(),
	}
}

func (e *mtrICMPEngine) resetProbeRoundMaps() {
	e.mu.Lock()
	e.sentAt = make(map[int]mtrProbeMeta)
	e.replied = make(map[int]*mtrProbeReply)
	e.mu.Unlock()
}

func (e *mtrICMPEngine) drainNotifySignal() {
	select {
	case <-e.notifyCh:
	default:
	}
}

func (e *mtrICMPEngine) rotateProbeEngineIfNeeded(ctx context.Context, probeCount int) error {
	if !seqWillWrap(atomic.LoadUint32(&e.seqCounter), probeCount) {
		return nil
	}
	return e.rotateEngine(ctx)
}

func (e *mtrICMPEngine) effectiveProbeRoundMax(maxHops int) int {
	if kf := atomic.LoadInt32(&e.knownFinalTTL); kf > 0 && int(kf) < maxHops {
		return int(kf)
	}
	return maxHops
}

func (e *mtrICMPEngine) initProbeRoundPreview(beginHop, effectiveMax int) {
	e.mu.Lock()
	e.curTtlSeq = make(map[int]int, effectiveMax-beginHop+1)
	e.curBeginHop = beginHop
	e.curEffectiveMax = effectiveMax
	e.mu.Unlock()
}

func (e *mtrICMPEngine) probeRoundDelay() time.Duration {
	probeDelay := time.Millisecond * time.Duration(e.config.PacketInterval)
	if probeDelay <= 0 {
		return 5 * time.Millisecond
	}
	return probeDelay
}

func (e *mtrICMPEngine) sendProbeSweep(ctx context.Context, round mtrProbeRoundState) error {
	for ttl := round.beginHop; ttl <= round.effectiveMax; ttl++ {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		sent, err := e.sendProbeForTTL(ctx, ttl, round.roundID)
		if err != nil {
			return err
		}
		if !sent {
			continue
		}
		if err := e.waitProbeInterval(ctx, round.probeDelay); err != nil {
			return err
		}
	}
	return nil
}

func (e *mtrICMPEngine) sendProbeForTTL(ctx context.Context, ttl int, roundID uint32) (bool, error) {
	seq := int(atomic.AddUint32(&e.seqCounter, 1) & 0xFFFF)

	// Pre-register the seq so onICMP can match it even for very short RTT replies.
	preStart := time.Now()
	e.mu.Lock()
	e.sentAt[seq] = mtrProbeMeta{ttl: ttl, start: preStart, roundID: roundID}
	e.curTtlSeq[ttl] = seq
	e.mu.Unlock()

	start, err := e.sendProbe(ctx, ttl, seq)
	if err != nil {
		// Roll back the pre-registered state on send failure.
		e.mu.Lock()
		delete(e.sentAt, seq)
		if e.curTtlSeq[ttl] == seq {
			delete(e.curTtlSeq, ttl)
		}
		e.mu.Unlock()
		if ctx.Err() != nil {
			return false, ctx.Err()
		}
		return false, nil
	}

	// Update the start timestamp to the actual send time for accurate RTT.
	e.mu.Lock()
	if meta, ok := e.sentAt[seq]; ok {
		meta.start = start
		e.sentAt[seq] = meta
	}
	e.mu.Unlock()
	return true, nil
}

func (e *mtrICMPEngine) waitProbeInterval(ctx context.Context, delay time.Duration) error {
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-time.After(delay):
		return nil
	}
}

func (e *mtrICMPEngine) waitForProbeReplies(ctx context.Context) {
	deadline := time.After(e.probeResponseTimeout())
	for e.hasPendingProbeReplies() {
		select {
		case <-ctx.Done():
			return
		case <-deadline:
			return
		case <-e.notifyCh:
		}
	}
}

func (e *mtrICMPEngine) probeResponseTimeout() time.Duration {
	timeout := e.config.Timeout
	if timeout <= 0 {
		return 2 * time.Second
	}
	return timeout
}

func (e *mtrICMPEngine) hasPendingProbeReplies() bool {
	e.mu.Lock()
	defer e.mu.Unlock()
	return len(e.sentAt) > 0
}

func (e *mtrICMPEngine) finalizeProbeRound(effectiveMax int) int {
	e.updateKnownFinalTTLFromRound()
	return e.roundFinalMax(effectiveMax)
}

func (e *mtrICMPEngine) updateKnownFinalTTLFromRound() {
	if rf := atomic.LoadInt32(&e.roundFinalTTL); rf > 0 {
		kf := atomic.LoadInt32(&e.knownFinalTTL)
		if kf < 0 || rf < kf {
			atomic.StoreInt32(&e.knownFinalTTL, rf)
		}
	}
}

func (e *mtrICMPEngine) roundFinalMax(effectiveMax int) int {
	if rf := atomic.LoadInt32(&e.roundFinalTTL); rf > 0 && int(rf) < effectiveMax {
		return int(rf)
	}
	return effectiveMax
}

func (e *mtrICMPEngine) buildProbeRoundResult(beginHop, finalMax int) *Result {
	res := &Result{Hops: make([][]Hop, finalMax)}
	e.mu.Lock()
	defer e.mu.Unlock()
	for ttl := beginHop; ttl <= finalMax; ttl++ {
		res.Hops[ttl-1] = []Hop{e.probeRoundHop(ttl)}
	}
	return res
}

func (e *mtrICMPEngine) probeRoundHop(ttl int) Hop {
	if seq, sent := e.curTtlSeq[ttl]; sent {
		if reply, ok := e.replied[seq]; ok {
			return Hop{
				Success: true,
				Address: reply.peer,
				TTL:     ttl,
				RTT:     reply.rtt,
				MPLS:    reply.mpls,
			}
		}
	}
	return Hop{
		Success: false,
		Address: nil,
		TTL:     ttl,
		RTT:     0,
		Error:   errHopLimitTimeout,
	}
}

// ---------------------------------------------------------------------------
// TCP/UDP 回退 prober：每轮调用 Traceroute + 指数退避
// ---------------------------------------------------------------------------

type mtrFallbackProber struct {
	method Method
	config Config
}

func (p *mtrFallbackProber) probeRound(ctx context.Context) (*Result, error) {
	return TracerouteWithContext(ctx, p.method, p.config)
}

func (p *mtrFallbackProber) close() {}

// ---------------------------------------------------------------------------
// ProbeTTL — single-TTL probing for per-hop scheduler
// ---------------------------------------------------------------------------

// ProbeTTL sends one ICMP echo at the given TTL and blocks until a response
// arrives, the timeout elapses, or ctx is cancelled.
func (e *mtrICMPEngine) ProbeTTL(ctx context.Context, ttl int) (mtrProbeResult, error) {
	// Serialize seq allocation + rotation check across concurrent ProbeTTL calls.
	e.sendMu.Lock()
	if seqWillWrap(atomic.LoadUint32(&e.seqCounter), 1) {
		if err := e.rotateEngine(ctx); err != nil {
			e.sendMu.Unlock()
			return mtrProbeResult{TTL: ttl}, fmt.Errorf("echoID rotation: %w", err)
		}
	}
	seq := int(atomic.AddUint32(&e.seqCounter, 1) & 0xFFFF)
	e.sendMu.Unlock()

	curRound := atomic.LoadUint32(&e.roundID)
	done := make(chan struct{})

	// Pre-register before sending so onICMP can match even very short RTT replies.
	preStart := time.Now()
	e.mu.Lock()
	e.sentAt[seq] = mtrProbeMeta{ttl: ttl, start: preStart, roundID: curRound}
	e.probeNotify[seq] = done
	e.mu.Unlock()

	sendStart, err := e.sendProbe(ctx, ttl, seq)
	if err != nil {
		// Roll back pre-registered state.
		e.mu.Lock()
		delete(e.sentAt, seq)
		e.closeProbeNotifyLocked(seq)
		e.mu.Unlock()
		if ctx.Err() != nil {
			return mtrProbeResult{TTL: ttl}, ctx.Err()
		}
		// Send failed: treat as timeout (no response for this TTL)
		return mtrProbeResult{TTL: ttl}, nil
	}

	// Update to actual send timestamp for accurate RTT.
	e.mu.Lock()
	if meta, ok := e.sentAt[seq]; ok {
		meta.start = sendStart
		e.sentAt[seq] = meta
	}
	e.mu.Unlock()

	timeout := e.config.Timeout
	if timeout <= 0 {
		timeout = 2 * time.Second
	}
	timer := time.NewTimer(timeout)
	defer timer.Stop()

	select {
	case <-done:
		e.mu.Lock()
		reply, ok := e.replied[seq]
		if ok {
			delete(e.replied, seq)
		}
		e.mu.Unlock()

		if ok && reply != nil {
			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    reply.peer,
				RTT:     reply.rtt,
				MPLS:    reply.mpls,
			}, nil
		}
		// Notified but no reply → was discarded (stale/bad RTT)
		return mtrProbeResult{TTL: ttl}, nil

	case <-timer.C:
		e.mu.Lock()
		delete(e.sentAt, seq)
		delete(e.probeNotify, seq)
		e.mu.Unlock()
		return mtrProbeResult{TTL: ttl}, nil

	case <-ctx.Done():
		e.mu.Lock()
		delete(e.sentAt, seq)
		delete(e.probeNotify, seq)
		e.mu.Unlock()
		return mtrProbeResult{TTL: ttl}, ctx.Err()
	}
}

// Reset invalidates all in-flight probes (bumps roundID) and clears
// knownFinalTTL. In-flight ProbeTTL calls get notified and return immediately.
func (e *mtrICMPEngine) Reset() error {
	e.resetFinalTTL()
	atomic.AddUint32(&e.roundID, 1)

	e.mu.Lock()
	for seq, ch := range e.probeNotify {
		close(ch)
		delete(e.probeNotify, seq)
	}
	e.sentAt = make(map[int]mtrProbeMeta)
	e.replied = make(map[int]*mtrProbeReply)
	e.mu.Unlock()

	return nil
}

// Close releases the underlying ICMP socket.
func (e *mtrICMPEngine) Close() error {
	e.close()
	return nil
}

// ---------------------------------------------------------------------------
// TCP/UDP 回退 TTL prober：单 TTL 探测
// ---------------------------------------------------------------------------

// mtrFallbackTTLProber uses Traceroute for single-TTL probing (TCP/UDP fallback).
type mtrFallbackTTLProber struct {
	method        Method
	config        Config
	asyncMetadata bool
}

func (p *mtrFallbackTTLProber) ProbeTTL(ctx context.Context, ttl int) (mtrProbeResult, error) {
	cfg := p.config
	cfg.BeginHop = ttl
	cfg.MaxHops = ttl
	cfg.NumMeasurements = 1
	cfg.MaxAttempts = 1
	cfg.ParallelRequests = 1
	cfg.RealtimePrinter = nil
	cfg.AsyncPrinter = nil
	if p.asyncMetadata {
		cfg.IPGeoSource = nil
		cfg.RDNS = false
		cfg.AlwaysWaitRDNS = false
	}

	res, err := TracerouteWithContext(ctx, p.method, cfg)
	if err != nil {
		return mtrProbeResult{TTL: ttl}, err
	}

	idx := ttl - 1
	if idx < 0 || idx >= len(res.Hops) || len(res.Hops[idx]) == 0 {
		return mtrProbeResult{TTL: ttl}, nil
	}

	h := res.Hops[idx][0]
	return mtrProbeResult{
		TTL:      ttl,
		Success:  h.Success && h.Address != nil,
		Addr:     h.Address,
		RTT:      h.RTT,
		MPLS:     h.MPLS,
		Hostname: h.Hostname,
		Geo:      h.Geo,
	}, nil
}

func (p *mtrFallbackTTLProber) Reset() error { return nil }
func (p *mtrFallbackTTLProber) Close() error { return nil }
