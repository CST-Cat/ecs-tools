package trace

import (
	"context"
	"errors"
	"fmt"
	"net"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/nxtrace/NTrace-core/ipgeo"
)

// ---------------------------------------------------------------------------
// Mock TTL prober for scheduler tests
// ---------------------------------------------------------------------------

type mockTTLProber struct {
	mu       sync.Mutex
	probeFn  func(ctx context.Context, ttl int) (mtrProbeResult, error)
	resetCnt int32
	closeCnt int32
	probeCnt int32
	probeLog []int // ttl of each probe call
}

func (m *mockTTLProber) ProbeTTL(ctx context.Context, ttl int) (mtrProbeResult, error) {
	atomic.AddInt32(&m.probeCnt, 1)
	m.mu.Lock()
	m.probeLog = append(m.probeLog, ttl)
	m.mu.Unlock()
	if m.probeFn != nil {
		return m.probeFn(ctx, ttl)
	}
	return mtrProbeResult{TTL: ttl}, nil
}

func (m *mockTTLProber) Reset() error {
	atomic.AddInt32(&m.resetCnt, 1)
	return nil
}

func (m *mockTTLProber) Close() error {
	atomic.AddInt32(&m.closeCnt, 1)
	return nil
}

func (m *mockTTLProber) getProbeCount() int {
	return int(atomic.LoadInt32(&m.probeCnt))
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

func TestScheduler_ResultBuildersUseBoundedHopCount(t *testing.T) {
	rt, err := newMTRSchedulerRuntime(
		context.Background(),
		&mockTTLProber{},
		NewMTRAggregator(),
		mtrSchedulerConfig{
			BeginHop:         1,
			MaxHops:          1 << 20,
			HopInterval:      time.Millisecond,
			ParallelRequests: 1,
		},
		nil,
		nil,
	)
	if err != nil {
		t.Fatalf("newMTRSchedulerRuntime returned error: %v", err)
	}
	if rt.maxHops != 255 {
		t.Fatalf("rt.maxHops = %d, want 255", rt.maxHops)
	}

	if got := len(rt.timeoutProbeResult(1).Hops); got != 255 {
		t.Fatalf("timeoutProbeResult hop len = %d, want 255", got)
	}
	if got := len(rt.singleProbeResult(1, mtrProbeResult{TTL: 1}).Hops); got != 255 {
		t.Fatalf("singleProbeResult hop len = %d, want 255", got)
	}
}

func TestScheduler_MaxPerHopCompletion(t *testing.T) {
	dstIP := net.ParseIP("10.0.0.5")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			// Simulate: TTL 3 is the destination
			if ttl == 3 {
				return mtrProbeResult{
					TTL:     ttl,
					Success: true,
					Addr:    &net.IPAddr{IP: dstIP},
					RTT:     10 * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: net.ParseIP(fmt.Sprintf("10.0.0.%d", ttl))},
				RTT:     time.Duration(ttl) * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()
	var lastIter int
	var snapshotCount int32

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          30,
		HopInterval:      time.Millisecond,
		MaxPerHop:        3,
		ParallelRequests: 5,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, func(iter int, stats []MTRHopStat) {
		atomic.AddInt32(&snapshotCount, 1)
		lastIter = iter
	}, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	// Should complete: each active TTL (1..3) should have 3 probes
	if lastIter != 3 {
		t.Errorf("expected final iteration=3, got %d", lastIter)
	}

	stats := agg.Snapshot()
	if len(stats) < 3 {
		t.Fatalf("expected at least 3 stats rows, got %d", len(stats))
	}

	for _, s := range stats {
		if s.TTL >= 1 && s.TTL <= 3 {
			if s.Snt != 3 {
				t.Errorf("TTL %d: expected Snt=3, got %d", s.TTL, s.Snt)
			}
		}
	}

	if atomic.LoadInt32(&prober.closeCnt) != 1 {
		t.Error("prober.Close() not called")
	}
}

func TestScheduler_ContextCancel(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())

	var probes int32
	prober := &mockTTLProber{
		probeFn: func(ctx context.Context, ttl int) (mtrProbeResult, error) {
			n := atomic.AddInt32(&probes, 1)
			if n >= 5 {
				cancel()
			}
			return mtrProbeResult{TTL: ttl}, nil
		},
	}

	agg := NewMTRAggregator()
	var snapshotCalled int32

	err := runMTRScheduler(ctx, prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          5,
		HopInterval:      time.Millisecond,
		MaxPerHop:        0, // unlimited
		ParallelRequests: 5,
		ProgressThrottle: time.Millisecond,
	}, func(_ int, _ []MTRHopStat) {
		atomic.AddInt32(&snapshotCalled, 1)
	}, nil)

	if !errors.Is(err, context.Canceled) {
		t.Errorf("expected context.Canceled, got %v", err)
	}
	if atomic.LoadInt32(&prober.closeCnt) != 1 {
		t.Error("prober.Close() not called on cancel")
	}
}

func TestScheduler_DestinationDetection(t *testing.T) {
	dstIP := net.ParseIP("8.8.8.8")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			if ttl >= 5 {
				return mtrProbeResult{
					TTL:     ttl,
					Success: true,
					Addr:    &net.IPAddr{IP: dstIP},
					RTT:     50 * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0.1")},
				RTT:     10 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          30,
		HopInterval:      time.Millisecond,
		MaxPerHop:        2,
		ParallelRequests: 1, // serialize to ensure dest detection before higher TTLs
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	// TTL 5 is the destination; higher TTLs should be disabled after detection.
	// With parallelism=1, at most TTL 6 could sneak in before the result is
	// processed (tick vs result race), so we allow a small margin.
	maxTTL := 0
	for _, s := range stats {
		if s.TTL > maxTTL {
			maxTTL = s.TTL
		}
	}
	if maxTTL > 6 {
		t.Errorf("expected max TTL <= 6 (destination detected at 5), got %d", maxTTL)
	}
}

func TestScheduler_Reset(t *testing.T) {
	var probes int32
	var resetOnce int32

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			atomic.AddInt32(&probes, 1)
			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0.1")},
				RTT:     5 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	var snapshotIters []int
	var iterMu sync.Mutex

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          2,
		HopInterval:      time.Millisecond,
		MaxPerHop:        4,
		ParallelRequests: 2,
		ProgressThrottle: time.Millisecond,
		IsResetRequested: func() bool {
			// Trigger reset after some probes have been done
			p := atomic.LoadInt32(&probes)
			if p >= 4 && atomic.CompareAndSwapInt32(&resetOnce, 0, 1) {
				return true
			}
			return false
		},
	}, func(iter int, _ []MTRHopStat) {
		iterMu.Lock()
		snapshotIters = append(snapshotIters, iter)
		iterMu.Unlock()
	}, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	// After reset, iteration should restart from 0→1
	// Final iteration should be 4 (maxPerHop=4)
	iterMu.Lock()
	defer iterMu.Unlock()

	if len(snapshotIters) == 0 {
		t.Fatal("expected at least one snapshot")
	}
	lastIter := snapshotIters[len(snapshotIters)-1]
	if lastIter != 4 {
		t.Errorf("expected last iteration=4, got %d", lastIter)
	}

	// prober.Reset should have been called once
	if atomic.LoadInt32(&prober.resetCnt) != 1 {
		t.Errorf("expected 1 Reset call, got %d", atomic.LoadInt32(&prober.resetCnt))
	}
}

func TestScheduler_Pause(t *testing.T) {
	var pauseFlag int32
	var probes int32

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			n := atomic.AddInt32(&probes, 1)
			if n == 2 {
				// Pause after 2 probes, resume after 50ms
				atomic.StoreInt32(&pauseFlag, 1)
				go func() {
					time.Sleep(50 * time.Millisecond)
					atomic.StoreInt32(&pauseFlag, 0)
				}()
			}
			if n >= 10 {
				cancel()
			}
			return mtrProbeResult{TTL: ttl}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(ctx, prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          2,
		HopInterval:      time.Millisecond,
		MaxPerHop:        0, // unlimited, cancelled by ctx
		ParallelRequests: 2,
		ProgressThrottle: time.Millisecond,
		IsPaused:         func() bool { return atomic.LoadInt32(&pauseFlag) == 1 },
	}, nil, nil)

	if !errors.Is(err, context.Canceled) {
		t.Errorf("expected context.Canceled, got %v", err)
	}
	// Should have probed at least 2 (before pause) + some more after resume
	p := atomic.LoadInt32(&probes)
	if p < 4 {
		t.Errorf("expected at least 4 probes (across pause), got %d", p)
	}
}

func TestScheduler_IterationIsMinSnt(t *testing.T) {
	// TTL 1 responds quickly, TTL 2 responds slowly
	var ttl1Count, ttl2Count int32

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			if ttl == 1 {
				atomic.AddInt32(&ttl1Count, 1)
				return mtrProbeResult{
					TTL:     1,
					Success: true,
					Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0.1")},
					RTT:     1 * time.Millisecond,
				}, nil
			}
			atomic.AddInt32(&ttl2Count, 1)
			time.Sleep(10 * time.Millisecond) // slower
			return mtrProbeResult{
				TTL:     2,
				Success: true,
				Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0.2")},
				RTT:     10 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()
	var finalIter int

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          2,
		HopInterval:      time.Millisecond,
		MaxPerHop:        3,
		ParallelRequests: 2,
		ProgressThrottle: time.Millisecond,
	}, func(iter int, _ []MTRHopStat) {
		finalIter = iter
	}, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	// Both TTLs should have 3 probes (MaxPerHop=3)
	if finalIter != 3 {
		t.Errorf("expected final iteration=3, got %d", finalIter)
	}
}

func TestScheduler_OnProbeCallback(t *testing.T) {
	dstIP := net.ParseIP("10.0.0.3")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			if ttl == 3 {
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  5 * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{
				TTL: ttl, Success: true,
				Addr: &net.IPAddr{IP: net.ParseIP("10.0.0.1")},
				RTT:  1 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	var callbackResults []mtrProbeResult
	var mu sync.Mutex

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          30,
		HopInterval:      time.Millisecond,
		MaxPerHop:        1,
		ParallelRequests: 5,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, func(result mtrProbeResult, _ int) {
		mu.Lock()
		callbackResults = append(callbackResults, result)
		mu.Unlock()
	})

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	mu.Lock()
	defer mu.Unlock()

	// Should have callbacks for TTL 1, 2, 3 (dest stops further TTLs)
	if len(callbackResults) < 3 {
		t.Errorf("expected at least 3 onProbe callbacks, got %d", len(callbackResults))
	}
}

func TestScheduler_BeginHopGreaterThanMaxHops(t *testing.T) {
	prober := &mockTTLProber{}
	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         10,
		MaxHops:          5,
		HopInterval:      time.Millisecond,
		MaxPerHop:        1,
		ParallelRequests: 1,
	}, nil, nil)

	if err == nil {
		t.Fatal("expected error for beginHop > maxHops")
	}
}

func TestScheduler_ConcurrencyLimit(t *testing.T) {
	var maxConcurrent int32
	var current int32

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			c := atomic.AddInt32(&current, 1)
			// Track max concurrent
			for {
				old := atomic.LoadInt32(&maxConcurrent)
				if c <= old || atomic.CompareAndSwapInt32(&maxConcurrent, old, c) {
					break
				}
			}
			time.Sleep(20 * time.Millisecond) // hold slot
			atomic.AddInt32(&current, -1)
			return mtrProbeResult{TTL: ttl}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          10,
		HopInterval:      time.Millisecond,
		MaxPerHop:        1,
		ParallelRequests: 3, // limit to 3 concurrent
		ProgressThrottle: time.Millisecond,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	mc := atomic.LoadInt32(&maxConcurrent)
	if mc > 3 {
		t.Errorf("expected max concurrent <= 3, got %d", mc)
	}
	if mc < 1 {
		t.Error("expected at least 1 concurrent probe")
	}
}

// TestMtrAddrToIP verifies the helper function.
func TestMtrAddrToIP(t *testing.T) {
	ip := net.ParseIP("1.2.3.4")

	if got := mtrAddrToIP(&net.IPAddr{IP: ip}); !got.Equal(ip) {
		t.Errorf("IPAddr: got %v, want %v", got, ip)
	}
	if got := mtrAddrToIP(&net.UDPAddr{IP: ip}); !got.Equal(ip) {
		t.Errorf("UDPAddr: got %v, want %v", got, ip)
	}
	if got := mtrAddrToIP(&net.TCPAddr{IP: ip}); !got.Equal(ip) {
		t.Errorf("TCPAddr: got %v, want %v", got, ip)
	}
	if got := mtrAddrToIP(nil); got != nil {
		t.Errorf("nil: got %v, want nil", got)
	}
}

// ---------------------------------------------------------------------------
// P1: Error budget tests
// ---------------------------------------------------------------------------

func TestScheduler_ErrorBudgetExhausted(t *testing.T) {
	// Every call to ProbeTTL returns an error.
	// With MaxConsecErrors=3, MaxPerHop=2, each TTL should eventually
	// complete because every 3 consecutive errors count as one completed timeout.
	errAlways := errors.New("always fail")
	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			return mtrProbeResult{TTL: ttl}, errAlways
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          2,
		HopInterval:      time.Millisecond,
		MaxPerHop:        2,
		MaxConsecErrors:  3,
		ParallelRequests: 2,
		ProgressThrottle: time.Millisecond,
	}, nil, nil)

	if err != nil {
		t.Fatalf("expected nil (completed), got %v", err)
	}

	// Each TTL should have 2 completed (timeout) events, each requiring 3 errors.
	// So total probes = 2 TTLs * 2 completions * 3 errors = 12.
	totalProbes := prober.getProbeCount()
	if totalProbes < 12 {
		t.Errorf("expected at least 12 probes (2 TTLs * 2 * 3 errors), got %d", totalProbes)
	}
}

func TestScheduler_ErrorBudgetEmitsOnProbe(t *testing.T) {
	// When error budget is exhausted, the synthetic timeout must also fire
	// the onProbe callback so that raw MTR sees the same record count as
	// the aggregator Snt.
	errAlways := errors.New("always fail")
	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			return mtrProbeResult{TTL: ttl}, errAlways
		},
	}

	agg := NewMTRAggregator()

	var mu sync.Mutex
	var rawRecords []mtrProbeResult

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          1,
		HopInterval:      time.Millisecond,
		MaxPerHop:        2,
		MaxConsecErrors:  3,
		ParallelRequests: 1,
		ProgressThrottle: time.Millisecond,
	}, nil, func(result mtrProbeResult, _ int) {
		mu.Lock()
		rawRecords = append(rawRecords, result)
		mu.Unlock()
	})

	if err != nil {
		t.Fatalf("expected nil (completed), got %v", err)
	}

	mu.Lock()
	defer mu.Unlock()

	// MaxPerHop=2, each requiring MaxConsecErrors=3 → 2 onProbe calls for TTL 1.
	if len(rawRecords) != 2 {
		t.Errorf("expected 2 onProbe callbacks (synthetic timeouts), got %d", len(rawRecords))
	}
	for i, r := range rawRecords {
		if r.TTL != 1 {
			t.Errorf("record[%d]: expected TTL=1, got %d", i, r.TTL)
		}
		if r.Success {
			t.Errorf("record[%d]: expected Success=false for timeout", i)
		}
	}
}

func TestScheduler_ErrorResetsOnSuccess(t *testing.T) {
	// Pattern: fail, fail, succeed, fail, fail, succeed — should never hit budget.
	var calls int32

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			n := atomic.AddInt32(&calls, 1)
			if n%3 != 0 { // every 3rd call succeeds
				return mtrProbeResult{TTL: ttl}, errors.New("fail")
			}
			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0.1")},
				RTT:     1 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          1,
		HopInterval:      time.Millisecond,
		MaxPerHop:        2, // need 2 successful
		MaxConsecErrors:  3, // budget = 3 consecutive
		ParallelRequests: 1,
		ProgressThrottle: time.Millisecond,
	}, nil, nil)

	if err != nil {
		t.Fatalf("expected nil (completed via successes), got %v", err)
	}

	stats := agg.Snapshot()
	found := false
	for _, s := range stats {
		if s.TTL == 1 && s.Snt >= 2 {
			found = true
		}
	}
	if !found {
		t.Error("TTL 1 should have at least 2 successful probes in aggregator")
	}
}

// ---------------------------------------------------------------------------
// P2: Fallback geo/hostname propagation tests
// ---------------------------------------------------------------------------

func TestScheduler_FallbackGeoCarriedToAggregator(t *testing.T) {
	fakeGeo := &ipgeo.IPGeoData{
		Asnumber: "AS13335",
		Country:  "美国",
		Prov:     "加利福尼亚",
		City:     "旧金山",
		Owner:    "Cloudflare",
	}

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			return mtrProbeResult{
				TTL:      ttl,
				Success:  true,
				Addr:     &net.IPAddr{IP: net.ParseIP("1.1.1.1")},
				RTT:      5 * time.Millisecond,
				Hostname: "one.one.one.one",
				Geo:      fakeGeo,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          1,
		HopInterval:      time.Millisecond,
		MaxPerHop:        1,
		ParallelRequests: 1,
		ProgressThrottle: time.Millisecond,
		FillGeo:          true, // should NOT re-fetch since probe carries Geo
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	if len(stats) == 0 {
		t.Fatal("expected at least 1 stat row")
	}

	s := stats[0]
	if s.Host != "one.one.one.one" {
		t.Errorf("expected Host='one.one.one.one', got %q", s.Host)
	}
	if s.Geo == nil {
		t.Fatal("expected Geo to be set, got nil")
	}
	if s.Geo.Asnumber != "AS13335" {
		t.Errorf("expected ASN='AS13335', got %q", s.Geo.Asnumber)
	}
}

func TestBuildMTRRawRecordFromProbe_PreResolvedGeo(t *testing.T) {
	fakeGeo := &ipgeo.IPGeoData{
		Asnumber:  "AS9808",
		Country:   "中国",
		CountryEn: "China",
		City:      "广州",
		CityEn:    "Guangzhou",
		Owner:     "ChinaMobile",
	}

	pr := mtrProbeResult{
		TTL:      3,
		Success:  true,
		Addr:     &net.IPAddr{IP: net.ParseIP("120.196.165.24")},
		RTT:      8 * time.Millisecond,
		Hostname: "bras-vlan365.gd.gd",
		Geo:      fakeGeo,
	}

	rec := buildMTRRawRecordFromProbe(5, pr, Config{Lang: "cn"})

	if rec.ASN != "AS9808" {
		t.Errorf("expected ASN='AS9808', got %q", rec.ASN)
	}
	if rec.Host != "bras-vlan365.gd.gd" {
		t.Errorf("expected Host='bras-vlan365.gd.gd', got %q", rec.Host)
	}
	if rec.City != "广州" {
		t.Errorf("expected City='广州', got %q", rec.City)
	}
	if rec.Country != "中国" {
		t.Errorf("expected Country='中国', got %q", rec.Country)
	}
	if rec.Owner != "ChinaMobile" {
		t.Errorf("expected Owner='ChinaMobile', got %q", rec.Owner)
	}
}

func TestBuildMTRRawRecordFromProbe_NoGeoNoSource_NoHostname(t *testing.T) {
	// When probe has no pre-resolved geo and config has no IPGeoSource/RDNS,
	// record should still have IP/RTT but no geo/host fields.
	pr := mtrProbeResult{
		TTL:     2,
		Success: true,
		Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0.5")},
		RTT:     3 * time.Millisecond,
	}

	rec := buildMTRRawRecordFromProbe(1, pr, Config{})

	if rec.IP != "10.0.0.5" {
		t.Errorf("expected IP='10.0.0.5', got %q", rec.IP)
	}
	if rec.ASN != "" || rec.Host != "" || rec.Country != "" {
		t.Errorf("expected empty geo/host fields, got ASN=%q Host=%q Country=%q",
			rec.ASN, rec.Host, rec.Country)
	}
}

// ---------------------------------------------------------------------------
// End-to-end: raw record count matches aggregator Snt under error budget
// ---------------------------------------------------------------------------

func TestScheduler_RawRecordCountMatchesAggSnt_ErrorBudget(t *testing.T) {
	// Simulate a mix of successes and persistent errors across 2 TTLs.
	// TTL 1: always succeeds. TTL 2: always errors.
	// With MaxPerHop=3 and MaxConsecErrors=2, both TTLs should complete
	// and the raw callback count per TTL must equal the aggregator Snt.

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			if ttl == 1 {
				return mtrProbeResult{
					TTL:     1,
					Success: true,
					Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0.1")},
					RTT:     5 * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{TTL: 2}, errors.New("persistent failure")
		},
	}

	agg := NewMTRAggregator()

	var mu sync.Mutex
	rawCountByTTL := map[int]int{}

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          2,
		HopInterval:      time.Millisecond,
		MaxPerHop:        3,
		MaxConsecErrors:  2,
		ParallelRequests: 1,
		ProgressThrottle: time.Millisecond,
	}, nil, func(result mtrProbeResult, _ int) {
		mu.Lock()
		rawCountByTTL[result.TTL]++
		mu.Unlock()
	})

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	sntByTTL := map[int]int{}
	for _, s := range stats {
		sntByTTL[s.TTL] = s.Snt
	}

	mu.Lock()
	defer mu.Unlock()

	for ttl := 1; ttl <= 2; ttl++ {
		rawCount := rawCountByTTL[ttl]
		snt := sntByTTL[ttl]
		if rawCount != snt {
			t.Errorf("TTL %d: raw callback count (%d) != aggregator Snt (%d)",
				ttl, rawCount, snt)
		}
		if snt != 3 {
			t.Errorf("TTL %d: expected Snt=3, got %d", ttl, snt)
		}
	}
}

// ---------------------------------------------------------------------------
// RDNS-only: IPGeoSource=nil && RDNS=true enters fetchIPData path
// ---------------------------------------------------------------------------

func TestBuildMTRRawRecordFromProbe_RDNSOnlyPath(t *testing.T) {
	// With IPGeoSource=nil and RDNS=true, the function should enter the
	// fetchIPData path (not skip it). We use 127.0.0.1 which typically
	// resolves to "localhost" via PTR. Even if RDNS fails in CI, the test
	// verifies the code path doesn't panic and the record is well-formed.
	pr := mtrProbeResult{
		TTL:     1,
		Success: true,
		Addr:    &net.IPAddr{IP: net.ParseIP("127.0.0.1")},
		RTT:     1 * time.Millisecond,
	}

	rec := buildMTRRawRecordFromProbe(1, pr, Config{
		RDNS:        true,
		IPGeoSource: nil, // no geo source — only RDNS
		Lang:        "en",
	})

	// Basic sanity: record must have IP and RTT regardless.
	if rec.IP != "127.0.0.1" {
		t.Errorf("expected IP='127.0.0.1', got %q", rec.IP)
	}
	if rec.RTTMs <= 0 {
		t.Errorf("expected positive RTTMs, got %f", rec.RTTMs)
	}
	// Geo fields should be empty (no IPGeoSource).
	if rec.ASN != "" {
		t.Errorf("expected empty ASN with no geo source, got %q", rec.ASN)
	}
	// Host may or may not be set depending on system RDNS for 127.0.0.1.
	// The key assertion is that we reached here without panic/skip.
	t.Logf("RDNS-only path: Host=%q (may vary by system)", rec.Host)
}

// ---------------------------------------------------------------------------
// Destination folding tests
// ---------------------------------------------------------------------------

func TestScheduler_HigherTTLDestinationRepliesDiscarded(t *testing.T) {
	// Destination is at TTL 3. Higher TTLs also return the destination IP
	// but with a small delay, ensuring TTL 3's result is processed first
	// (setting knownFinalTTL=3). The delayed higher-TTL probes are now
	// DISCARDED — not folded into TTL 3.
	dstIP := net.ParseIP("10.0.0.99")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			if ttl > 3 {
				// Higher TTLs return destination but after a delay,
				// so TTL 3's result is processed first.
				time.Sleep(30 * time.Millisecond)
				return mtrProbeResult{
					TTL:     ttl,
					Success: true,
					Addr:    &net.IPAddr{IP: dstIP},
					RTT:     time.Duration(ttl) * time.Millisecond,
				}, nil
			}
			if ttl == 3 {
				return mtrProbeResult{
					TTL:     ttl,
					Success: true,
					Addr:    &net.IPAddr{IP: dstIP},
					RTT:     time.Duration(ttl) * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0.1")},
				RTT:     time.Duration(ttl) * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	var mu sync.Mutex
	probeByTTL := map[int]int{}

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          6,
		HopInterval:      time.Millisecond,
		MaxPerHop:        3,
		ParallelRequests: 6, // enough to launch TTLs 1-6 simultaneously
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, func(result mtrProbeResult, _ int) {
		mu.Lock()
		probeByTTL[result.TTL]++
		mu.Unlock()
	})

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	sntByTTL := map[int]int{}
	for _, s := range stats {
		sntByTTL[s.TTL] = s.Snt
	}

	// TTL 3 (finalTTL) should have ONLY its own probes — Snt == MaxPerHop (no fold)
	if sntByTTL[3] != 3 {
		t.Errorf("TTL 3 (final): expected Snt == 3 (own probes only, no fold), got %d", sntByTTL[3])
	}

	// TTLs above final should NOT appear in aggregator (discarded)
	for ttl := 4; ttl <= 6; ttl++ {
		if sntByTTL[ttl] > 0 {
			t.Errorf("TTL %d: expected Snt=0 (discarded), got %d", ttl, sntByTTL[ttl])
		}
	}

	// onProbe callbacks must NOT fire for discarded higher-TTL results
	mu.Lock()
	defer mu.Unlock()
	for ttl := 4; ttl <= 6; ttl++ {
		if probeByTTL[ttl] > 0 {
			t.Errorf("onProbe: TTL %d should have 0 callbacks (discarded), got %d", ttl, probeByTTL[ttl])
		}
	}
	// Also verify that NO folded callbacks appeared at TTL 3 from higher-TTL probes:
	// TTL 3's callback count must equal its Snt.
	if probeByTTL[3] != sntByTTL[3] {
		t.Errorf("onProbe: TTL 3 callback count (%d) != Snt (%d); suggests folded callbacks leaked", probeByTTL[3], sntByTTL[3])
	}
}

func TestScheduler_DiscardedDestinationRepliesCannotExceedMaxPerHop(t *testing.T) {
	// With discard semantics, higher TTL destination replies are discarded
	// entirely, so they can never push finalTTL's Snt above MaxPerHop.
	dstIP := net.ParseIP("10.0.0.99")

	var probeCount int32
	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			atomic.AddInt32(&probeCount, 1)
			if ttl >= 2 {
				// All TTLs >= 2 hit destination
				return mtrProbeResult{
					TTL:     ttl,
					Success: true,
					Addr:    &net.IPAddr{IP: dstIP},
					RTT:     5 * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0.1")},
				RTT:     1 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          10,
		HopInterval:      time.Millisecond,
		MaxPerHop:        2, // strict cap
		ParallelRequests: 10,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	for _, s := range stats {
		if s.TTL == 2 {
			// TTL 2 is the finalTTL; higher TTL destination replies are
			// discarded entirely, so Snt must equal exactly MaxPerHop
			// (only own probes counted).
			if s.Snt > 2 {
				t.Errorf("TTL 2 (final): Snt=%d exceeds MaxPerHop=2 (discard violation)", s.Snt)
			}
		}
	}

	// Verify no higher TTLs have stats in the aggregator
	for _, s := range stats {
		if s.TTL > 2 && s.IP == dstIP.String() {
			t.Errorf("TTL %d: should not have dst-ip stats (discarded), got Snt=%d", s.TTL, s.Snt)
		}
	}
}

func TestScheduler_NonDestinationRepliesOnDisabledHigherTTLDiscarded(t *testing.T) {
	// If a higher TTL (after being disabled) returns a non-destination IP,
	// that reply should be silently discarded — not folded, not recorded.
	// Higher TTLs are delayed so TTL 3 (destination) is processed first.
	dstIP := net.ParseIP("10.0.0.99")

	var mu sync.Mutex
	var probeResults []mtrProbeResult

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			if ttl == 3 {
				// TTL 3 is destination — returns quickly
				return mtrProbeResult{
					TTL:     ttl,
					Success: true,
					Addr:    &net.IPAddr{IP: dstIP},
					RTT:     5 * time.Millisecond,
				}, nil
			}
			if ttl > 3 {
				// Higher TTLs return a non-destination intermediate IP
				// after a delay, so they arrive after TTL 3 sets disabled.
				time.Sleep(30 * time.Millisecond)
				return mtrProbeResult{
					TTL:     ttl,
					Success: true,
					Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0.50")},
					RTT:     3 * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0." + fmt.Sprintf("%d", ttl))},
				RTT:     time.Duration(ttl) * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          6,
		HopInterval:      time.Millisecond,
		MaxPerHop:        2,
		ParallelRequests: 6, // all TTLs may launch before destination detected
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, func(result mtrProbeResult, _ int) {
		mu.Lock()
		probeResults = append(probeResults, result)
		mu.Unlock()
	})

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	// Non-destination replies from disabled TTLs (4, 5, 6) with IP 10.0.0.50
	// should have been discarded. Check that the aggregator has no entries
	// for TTLs > 3 with the intermediate IP.
	stats := agg.Snapshot()
	for _, s := range stats {
		if s.TTL > 3 && s.IP == "10.0.0.50" {
			t.Errorf("TTL %d: non-destination reply (10.0.0.50) should have been discarded, but appeared in aggregator", s.TTL)
		}
	}
}

func TestScheduler_FinalTTLLowered_MigratesStatsToNewFinal(t *testing.T) {
	// Scenario: higher TTL (12) returns destination first, establishing
	// knownFinalTTL=12. Then a lower TTL (7) returns destination, lowering
	// knownFinalTTL to 7. The stats already recorded at TTL 12 must be
	// migrated to TTL 7 — no ghost row at TTL 12 should remain.
	dstIP := net.ParseIP("10.0.0.99")

	var mu sync.Mutex
	callOrder := map[int]int{} // ttl → order of first return
	var callSeq int32

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			mu.Lock()
			if callOrder[ttl] == 0 {
				callOrder[ttl] = int(atomic.AddInt32(&callSeq, 1))
			}
			mu.Unlock()

			if ttl == 12 {
				// TTL 12 returns destination quickly
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  3 * time.Millisecond,
				}, nil
			}
			if ttl == 7 {
				// TTL 7 returns destination after a delay,
				// ensuring TTL 12 is processed first.
				time.Sleep(50 * time.Millisecond)
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  5 * time.Millisecond,
				}, nil
			}
			// Intermediate hops
			return mtrProbeResult{
				TTL: ttl, Success: true,
				Addr: &net.IPAddr{IP: net.ParseIP("10.0.0." + fmt.Sprintf("%d", ttl))},
				RTT:  time.Duration(ttl) * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          15,
		HopInterval:      time.Millisecond,
		MaxPerHop:        3,
		ParallelRequests: 15,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	sntByTTL := map[int]int{}
	ipByTTL := map[int]string{}
	for _, s := range stats {
		sntByTTL[s.TTL] = s.Snt
		ipByTTL[s.TTL] = s.IP
	}

	// TTL 12 should have NO stats — cleared when finalTTL lowered to 7
	if sntByTTL[12] > 0 {
		t.Errorf("TTL 12 should have 0 stats after clearing, got Snt=%d (ghost row!)", sntByTTL[12])
	}

	// TTL 7 (new final) should have stats (its own probes only)
	if sntByTTL[7] < 3 {
		t.Errorf("TTL 7 (final): expected Snt >= 3, got %d", sntByTTL[7])
	}

	// Only one row should have the destination IP
	dstIPRows := 0
	for _, s := range stats {
		if s.IP == "10.0.0.99" {
			dstIPRows++
			if s.TTL != 7 {
				t.Errorf("destination IP found at TTL %d, expected only at TTL 7", s.TTL)
			}
		}
	}
	if dstIPRows == 0 {
		t.Error("expected at least one row with destination IP")
	}
	if dstIPRows > 1 {
		t.Errorf("expected exactly 1 dst-ip row (at TTL 7), got %d (duplicate!)", dstIPRows)
	}
}

func TestScheduler_FinalTTLLowered_ChainMigration(t *testing.T) {
	// Chain scenario: TTL 12 → final. Then TTL 9 → final (migrates 12→9).
	// Then TTL 7 → final (migrates 9→7). All stats end up at TTL 7.
	dstIP := net.ParseIP("10.0.0.99")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			if ttl == 12 {
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  3 * time.Millisecond,
				}, nil
			}
			if ttl == 9 {
				time.Sleep(30 * time.Millisecond)
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  4 * time.Millisecond,
				}, nil
			}
			if ttl == 7 {
				time.Sleep(60 * time.Millisecond)
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  5 * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{
				TTL: ttl, Success: true,
				Addr: &net.IPAddr{IP: net.ParseIP("10.0.0." + fmt.Sprintf("%d", ttl))},
				RTT:  time.Duration(ttl) * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          15,
		HopInterval:      time.Millisecond,
		MaxPerHop:        2,
		ParallelRequests: 15,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	for _, s := range stats {
		if s.IP == "10.0.0.99" && s.TTL != 7 {
			t.Errorf("destination IP at TTL %d, expected only at TTL 7 after chain lowering", s.TTL)
		}
	}

	// TTLs 9 and 12 should not have dst-ip stats (cleared during lowering)
	for _, s := range stats {
		if (s.TTL == 9 || s.TTL == 12) && s.IP == "10.0.0.99" {
			t.Errorf("TTL %d: ghost row with dst-ip after chain lowering", s.TTL)
		}
	}
}

// ---------------------------------------------------------------------------
// New regression tests: discard over-final destination replies
// ---------------------------------------------------------------------------

func TestScheduler_LateHigherTTLDestinationReply_Discarded_NoSntBump(t *testing.T) {
	// Scheduler dispatches multiple TTLs concurrently.
	// TTL 3 hits destination first → sets knownFinalTTL=3 and disables >3.
	// Later: originTTL=5 returns destination reply (late) → MUST be discarded.
	dstIP := net.ParseIP("10.0.0.99")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			if ttl == 3 {
				// Destination — returns fast
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  3 * time.Millisecond,
				}, nil
			}
			if ttl == 5 {
				// Late destination reply — delayed so TTL 3 is processed first
				time.Sleep(40 * time.Millisecond)
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  8 * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{
				TTL: ttl, Success: true,
				Addr: &net.IPAddr{IP: net.ParseIP(fmt.Sprintf("10.0.0.%d", ttl))},
				RTT:  time.Duration(ttl) * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	var mu sync.Mutex
	var callbackCount int

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          6,
		HopInterval:      time.Millisecond,
		MaxPerHop:        2,
		ParallelRequests: 6,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, func(result mtrProbeResult, _ int) {
		mu.Lock()
		callbackCount++
		mu.Unlock()
	})

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	sntByTTL := map[int]int{}
	for _, s := range stats {
		sntByTTL[s.TTL] = s.Snt
	}

	// Final hop TTL 3 should have exactly MaxPerHop (2) Snt — no bump from TTL 5
	if sntByTTL[3] != 2 {
		t.Errorf("TTL 3 (final): expected Snt=2 (MaxPerHop, own probes only), got %d", sntByTTL[3])
	}

	// TTL 5 should have 0 Snt — discarded
	if sntByTTL[5] > 0 {
		t.Errorf("TTL 5: expected Snt=0 (discarded late dst reply), got %d", sntByTTL[5])
	}

	// Callback count should equal sum of Snt across active TTLs only
	mu.Lock()
	totalSnt := 0
	for _, s := range stats {
		totalSnt += s.Snt
	}
	if callbackCount != totalSnt {
		t.Errorf("callback count (%d) != total Snt (%d); discarded results may have leaked", callbackCount, totalSnt)
	}
	mu.Unlock()
}

func TestScheduler_DiscardedOverFinal_DoesNotEmitOnProbe(t *testing.T) {
	// Provide onProbe hook that appends all records.
	// Trigger late over-final destination reply.
	// Assert no record appended for discarded result.
	dstIP := net.ParseIP("10.0.0.99")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			if ttl == 2 {
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  5 * time.Millisecond,
				}, nil
			}
			if ttl > 2 {
				time.Sleep(30 * time.Millisecond)
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  10 * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{
				TTL: ttl, Success: true,
				Addr: &net.IPAddr{IP: net.ParseIP("10.0.0.1")},
				RTT:  1 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	var mu sync.Mutex
	var records []mtrProbeResult

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          5,
		HopInterval:      time.Millisecond,
		MaxPerHop:        2,
		ParallelRequests: 5,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, func(result mtrProbeResult, _ int) {
		mu.Lock()
		records = append(records, result)
		mu.Unlock()
	})

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	mu.Lock()
	defer mu.Unlock()

	// No record should have TTL > 2 (all discarded)
	for i, r := range records {
		if r.TTL > 2 {
			t.Errorf("record[%d]: TTL %d should not have been emitted (discarded over-final)", i, r.TTL)
		}
	}

	// Record count must match aggregator Snt sum
	stats := agg.Snapshot()
	totalSnt := 0
	for _, s := range stats {
		totalSnt += s.Snt
	}
	if len(records) != totalSnt {
		t.Errorf("record count (%d) != total Snt (%d); 1:1 onProbe/Snt invariant violated", len(records), totalSnt)
	}
}

func TestScheduler_FinalTTLLowering_Chain_WithMaxPerHop_NoGhostRow_StableStats(t *testing.T) {
	// Construct deterministic RTT samples with chain lowering:
	// Provisional final at TTL 12 → lowered to 9 → lowered to 7.
	// MaxPerHop=3 (small). Verify no ghost rows, stats stable.
	dstIP := net.ParseIP("10.0.0.99")

	// RTT values for deterministic stat validation
	rttMap := map[int][]time.Duration{
		7:  {5 * time.Millisecond, 6 * time.Millisecond, 7 * time.Millisecond},
		9:  {10 * time.Millisecond, 11 * time.Millisecond},
		12: {20 * time.Millisecond},
	}
	var mu sync.Mutex
	callCountByTTL := map[int]int{}

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			mu.Lock()
			callCountByTTL[ttl]++
			n := callCountByTTL[ttl]
			mu.Unlock()

			if ttl == 12 {
				// First to return destination
				rtt := 20 * time.Millisecond
				if n <= len(rttMap[12]) {
					rtt = rttMap[12][n-1]
				}
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  rtt,
				}, nil
			}
			if ttl == 9 {
				time.Sleep(30 * time.Millisecond)
				rtt := 11 * time.Millisecond
				if n <= len(rttMap[9]) {
					rtt = rttMap[9][n-1]
				}
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  rtt,
				}, nil
			}
			if ttl == 7 {
				time.Sleep(60 * time.Millisecond)
				rtt := 7 * time.Millisecond
				if n <= len(rttMap[7]) {
					rtt = rttMap[7][n-1]
				}
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  rtt,
				}, nil
			}
			return mtrProbeResult{
				TTL: ttl, Success: true,
				Addr: &net.IPAddr{IP: net.ParseIP(fmt.Sprintf("10.0.0.%d", ttl))},
				RTT:  time.Duration(ttl) * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          15,
		HopInterval:      time.Millisecond,
		MaxPerHop:        3,
		ParallelRequests: 15,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	sntByTTL := map[int]int{}
	ipByTTL := map[int]string{}
	var finalHopStat *MTRHopStat
	for i, s := range stats {
		sntByTTL[s.TTL] = s.Snt
		ipByTTL[s.TTL] = s.IP
		if s.TTL == 7 && s.IP == dstIP.String() {
			finalHopStat = &stats[i]
		}
	}

	// No ghost rows at TTL 12 or 9 with destination IP
	for _, ttl := range []int{12, 9} {
		if ipByTTL[ttl] == dstIP.String() {
			t.Errorf("TTL %d: ghost row with dst-ip after chain migration", ttl)
		}
	}

	// Final hop is TTL 7
	if finalHopStat == nil {
		t.Fatal("expected final hop at TTL 7 with destination IP")
	}

	// Snt <= MaxPerHop
	if finalHopStat.Snt > 3 {
		t.Errorf("TTL 7 (final): Snt=%d exceeds MaxPerHop=3", finalHopStat.Snt)
	}

	// Snt must be > 0 (at least the migrated + own)
	if finalHopStat.Snt == 0 {
		t.Error("TTL 7 (final): Snt=0, expected > 0 after chain lowering")
	}

	// Avg should be reasonable (> 0 and not NaN)
	if finalHopStat.Avg <= 0 {
		t.Errorf("TTL 7 (final): Avg=%f, expected > 0 (stable stats)", finalHopStat.Avg)
	}

	// StDev should be non-negative
	if finalHopStat.StDev < 0 {
		t.Errorf("TTL 7 (final): StDev=%f, expected >= 0 (stable stats)", finalHopStat.StDev)
	}

	// Destination IP should appear exactly once across all stats rows
	dstIPCount := 0
	for _, s := range stats {
		if s.IP == dstIP.String() {
			dstIPCount++
			if s.TTL != 7 {
				t.Errorf("destination IP found at TTL %d, expected only at TTL 7", s.TTL)
			}
		}
	}
	if dstIPCount != 1 {
		t.Errorf("expected exactly 1 row with dst-ip (at TTL 7), got %d", dstIPCount)
	}
}

// ---------------------------------------------------------------------------
// Regression: final hop Snt must NOT exceed other hops
// ---------------------------------------------------------------------------

func TestScheduler_FinalHopSntNotInflated_NoLowering(t *testing.T) {
	// Simple case: destination is at TTL 5, no lowering occurs.
	// All active TTLs should have equal Snt after completion.
	dstIP := net.ParseIP("10.0.0.99")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			if ttl == 5 {
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  5 * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{
				TTL: ttl, Success: true,
				Addr: &net.IPAddr{IP: net.ParseIP(fmt.Sprintf("10.0.0.%d", ttl))},
				RTT:  time.Duration(ttl) * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          30,
		HopInterval:      time.Millisecond,
		MaxPerHop:        5,
		ParallelRequests: 30,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	sntByTTL := map[int]int{}
	for _, s := range stats {
		sntByTTL[s.TTL] = s.Snt
	}

	// All active TTLs (1-5) should have exactly MaxPerHop Snt
	for ttl := 1; ttl <= 5; ttl++ {
		if sntByTTL[ttl] != 5 {
			t.Errorf("TTL %d: Snt=%d, expected 5 (MaxPerHop)", ttl, sntByTTL[ttl])
		}
	}
}

func TestScheduler_FinalHopSntNotInflated_WithLowering(t *testing.T) {
	// Lowering scenario: TTL 8 hits destination first, then TTL 5 lowers it.
	// After completion, TTL 5 (final) should have Snt == MaxPerHop, same as
	// other hops — NOT inflated by migrated data from TTL 8.
	dstIP := net.ParseIP("10.0.0.99")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			if ttl == 8 {
				// Returns destination quickly (discovered first as provisional final)
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  3 * time.Millisecond,
				}, nil
			}
			if ttl == 5 {
				// Real final — returns after delay so TTL 8 is processed first
				time.Sleep(30 * time.Millisecond)
				return mtrProbeResult{
					TTL: ttl, Success: true,
					Addr: &net.IPAddr{IP: dstIP},
					RTT:  5 * time.Millisecond,
				}, nil
			}
			return mtrProbeResult{
				TTL: ttl, Success: true,
				Addr: &net.IPAddr{IP: net.ParseIP(fmt.Sprintf("10.0.0.%d", ttl))},
				RTT:  time.Duration(ttl) * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          15,
		HopInterval:      time.Millisecond,
		MaxPerHop:        4,
		ParallelRequests: 15,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	sntByTTL := map[int]int{}
	for _, s := range stats {
		sntByTTL[s.TTL] = s.Snt
	}

	// All active TTLs (1-5) should have exactly MaxPerHop Snt
	for ttl := 1; ttl <= 5; ttl++ {
		if sntByTTL[ttl] != 4 {
			t.Errorf("TTL %d: Snt=%d, expected 4 (MaxPerHop, no inflation)", ttl, sntByTTL[ttl])
		}
	}

	// Old provisional final (TTL 8) should have NO data (cleared, not migrated)
	if sntByTTL[8] > 0 {
		t.Errorf("TTL 8 (old provisional final): Snt=%d, expected 0 (cleared)", sntByTTL[8])
	}
}

// ---------------------------------------------------------------------------
// Multi in-flight per hop: high-loss hops should accumulate Snt equally
// ---------------------------------------------------------------------------

func TestScheduler_MultiInFlightPerHop_HighLossEqualSnt(t *testing.T) {
	// This test reproduces the original bug: when each TTL allows only 1
	// in-flight probe and nextAt is based on completion time, a TTL with
	// high packet loss (simulated by long timeout) accumulates Snt much
	// slower than a low-loss TTL.
	//
	// With the multi-in-flight fix (inFlightCount counter + nextAt based on
	// launch time), all TTLs should complete with equal Snt = MaxPerHop.
	dstIP := net.ParseIP("10.0.0.5")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			// TTL 1: fast responder (no loss)
			// TTL 2: 80% loss (simulated as 80% of probes sleeping 200ms = "timeout")
			// TTL 3: destination, fast
			ip := net.ParseIP(fmt.Sprintf("10.0.0.%d", ttl))
			if ttl == 3 {
				ip = dstIP
			}

			if ttl == 2 {
				// Simulate high RTT / timeout — takes longer than other hops.
				// With multi-in-flight, the scheduler should still keep up.
				time.Sleep(50 * time.Millisecond)
			}

			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: ip},
				RTT:     5 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:          1,
		MaxHops:           30,
		HopInterval:       10 * time.Millisecond,
		MaxPerHop:         10,
		MaxInFlightPerHop: 3,
		ParallelRequests:  30,
		ProgressThrottle:  time.Millisecond,
		DstIP:             dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	sntByTTL := map[int]int{}
	for _, s := range stats {
		sntByTTL[s.TTL] = s.Snt
	}

	// All active TTLs should have exactly MaxPerHop probes
	for ttl := 1; ttl <= 3; ttl++ {
		if sntByTTL[ttl] != 10 {
			t.Errorf("TTL %d: Snt=%d, expected 10 (MaxPerHop)", ttl, sntByTTL[ttl])
		}
	}
}

func TestScheduler_MultiInFlightPerHop_TimeoutHopsKeepUp(t *testing.T) {
	// Simulate real packet loss: some probes return quickly (RTT), others
	// "time out" by sleeping the full timeout duration. With multi-in-flight,
	// the slow (timed-out) hop should still reach MaxPerHop because the
	// scheduler launches new probes while old ones are still in-flight.
	dstIP := net.ParseIP("10.0.0.10")

	var ttl2Calls int32

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			ip := net.ParseIP(fmt.Sprintf("10.0.0.%d", ttl))
			if ttl == 5 {
				ip = dstIP
			}

			if ttl == 3 {
				// 50% of probes "time out" (take a long time)
				n := atomic.AddInt32(&ttl2Calls, 1)
				if n%2 == 0 {
					time.Sleep(100 * time.Millisecond) // "timeout"
					// Return as no-reply (timeout)
					return mtrProbeResult{TTL: ttl}, nil
				}
			}

			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: ip},
				RTT:     2 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:          1,
		MaxHops:           30,
		HopInterval:       10 * time.Millisecond,
		MaxPerHop:         6,
		MaxInFlightPerHop: 3,
		ParallelRequests:  30,
		ProgressThrottle:  time.Millisecond,
		DstIP:             dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	sntByTTL := map[int]int{}
	for _, s := range stats {
		sntByTTL[s.TTL] = s.Snt
	}

	// All TTLs should complete with MaxPerHop probes
	for ttl := 1; ttl <= 5; ttl++ {
		if sntByTTL[ttl] != 6 {
			t.Errorf("TTL %d: Snt=%d, expected 6 (MaxPerHop)", ttl, sntByTTL[ttl])
		}
	}
}

func TestScheduler_NextAtBasedOnLaunchTime(t *testing.T) {
	// Verify that the scheduler doesn't wait for probe completion to set nextAt.
	// If a probe takes 200ms and hopInterval is 10ms, a second probe for the same
	// TTL should launch ~10ms after the first (not 210ms after).
	var launches []time.Time
	var mu sync.Mutex

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			mu.Lock()
			launches = append(launches, time.Now())
			mu.Unlock()

			// Simulate slow probe (timeout-like)
			time.Sleep(200 * time.Millisecond)

			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: net.ParseIP("10.0.0.1")},
				RTT:     200 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:          1,
		MaxHops:           1,
		HopInterval:       50 * time.Millisecond,
		MaxPerHop:         3,
		MaxInFlightPerHop: 3,
		ParallelRequests:  10,
		ProgressThrottle:  time.Millisecond,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	mu.Lock()
	defer mu.Unlock()

	if len(launches) < 3 {
		t.Fatalf("expected 3 launches, got %d", len(launches))
	}

	// With launch-based nextAt and hopInterval=50ms, launches 2 and 3 should
	// start ~50ms and ~100ms after launch 1 respectively, NOT 250ms and 500ms
	// (which would be the case with completion-based nextAt).
	for i := 1; i < len(launches); i++ {
		gap := launches[i].Sub(launches[i-1])
		// Allow generous tolerance (50ms interval + scheduling jitter up to 50ms)
		if gap > 150*time.Millisecond {
			t.Errorf("gap between launch %d and %d: %v (expected < 150ms with launch-based nextAt)",
				i-1, i, gap)
		}
	}
}

func TestScheduler_MaxPerHopRespectedWithMultiInFlight(t *testing.T) {
	// Ensure that with multiple in-flight probes per hop, we never exceed
	// MaxPerHop in the final Snt count. The scheduler should stop launching
	// when completed + inFlightCount >= MaxPerHop.
	dstIP := net.ParseIP("10.0.0.3")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			// All probes take some time to complete
			time.Sleep(30 * time.Millisecond)

			ip := net.ParseIP(fmt.Sprintf("10.0.0.%d", ttl))
			if ttl == 3 {
				ip = dstIP
			}
			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: ip},
				RTT:     5 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:          1,
		MaxHops:           30,
		HopInterval:       5 * time.Millisecond,
		MaxPerHop:         4,
		MaxInFlightPerHop: 5, // higher than MaxPerHop to test the guard
		ParallelRequests:  30,
		ProgressThrottle:  time.Millisecond,
		DstIP:             dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	for _, s := range stats {
		if s.TTL >= 1 && s.TTL <= 3 {
			if s.Snt > 4 {
				t.Errorf("TTL %d: Snt=%d exceeds MaxPerHop=4", s.TTL, s.Snt)
			}
			if s.Snt != 4 {
				t.Errorf("TTL %d: Snt=%d, expected exactly 4 (MaxPerHop)", s.TTL, s.Snt)
			}
		}
	}
}

func TestScheduler_SingleInFlightPerHopConfig(t *testing.T) {
	// When MaxInFlightPerHop=1, behavior should match the old single-inflight
	// mode (for backward compatibility verification). The test just ensures
	// completion without error.
	dstIP := net.ParseIP("10.0.0.3")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			ip := net.ParseIP(fmt.Sprintf("10.0.0.%d", ttl))
			if ttl == 3 {
				ip = dstIP
			}
			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: ip},
				RTT:     1 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:          1,
		MaxHops:           30,
		HopInterval:       time.Millisecond,
		MaxPerHop:         3,
		MaxInFlightPerHop: 1, // explicit single in-flight
		ParallelRequests:  5,
		ProgressThrottle:  time.Millisecond,
		DstIP:             dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	for _, s := range stats {
		if s.TTL >= 1 && s.TTL <= 3 && s.Snt != 3 {
			t.Errorf("TTL %d: Snt=%d, expected 3", s.TTL, s.Snt)
		}
	}
}

func TestScheduler_DynamicMaxInFlightPerHop(t *testing.T) {
	// Verify that when MaxInFlightPerHop is not explicitly set, the scheduler
	// computes it as ceil(timeout / hopInterval) + 1. With a large timeout
	// relative to hopInterval, the dynamic value should be high enough that
	// even fully-timing-out hops keep up with fast hops.
	//
	// Setup: timeout=500ms, hopInterval=50ms → dynamic = ceil(500/50)+1 = 11.
	// TTL 2 always "times out" (sleeps 500ms); TTL 1,3 are fast.
	// MaxPerHop=8: with dynamic=11, all 8 probes for TTL 2 can be in-flight
	// simultaneously, so TTL 2 completes at roughly the same wall-clock as
	// the fast hops.
	dstIP := net.ParseIP("10.0.0.3")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			ip := net.ParseIP(fmt.Sprintf("10.0.0.%d", ttl))
			if ttl == 3 {
				ip = dstIP
			}
			if ttl == 2 {
				time.Sleep(500 * time.Millisecond) // full "timeout"
			}
			return mtrProbeResult{
				TTL:     ttl,
				Success: true,
				Addr:    &net.IPAddr{IP: ip},
				RTT:     2 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          30,
		HopInterval:      50 * time.Millisecond,
		Timeout:          500 * time.Millisecond, // → dynamic maxInFlightPerHop = 11
		MaxPerHop:        8,
		ParallelRequests: 30,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
		// MaxInFlightPerHop intentionally 0 → dynamic
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	sntByTTL := map[int]int{}
	for _, s := range stats {
		sntByTTL[s.TTL] = s.Snt
	}

	for ttl := 1; ttl <= 3; ttl++ {
		if sntByTTL[ttl] != 8 {
			t.Errorf("TTL %d: Snt=%d, expected 8 (MaxPerHop)", ttl, sntByTTL[ttl])
		}
	}
}

func TestScheduler_DynamicMaxInFlightPerHop_SmallTimeout(t *testing.T) {
	// With timeout < hopInterval, dynamic = ceil(t/h)+1 = 1+1 = 2, not 1.
	// This ensures at least 2 slots so pipelining still works.
	dstIP := net.ParseIP("10.0.0.2")

	prober := &mockTTLProber{
		probeFn: func(_ context.Context, ttl int) (mtrProbeResult, error) {
			ip := net.ParseIP(fmt.Sprintf("10.0.0.%d", ttl))
			if ttl == 2 {
				ip = dstIP
			}
			return mtrProbeResult{
				TTL: ttl, Success: true,
				Addr: &net.IPAddr{IP: ip},
				RTT:  1 * time.Millisecond,
			}, nil
		},
	}

	agg := NewMTRAggregator()

	err := runMTRScheduler(context.Background(), prober, agg, mtrSchedulerConfig{
		BeginHop:         1,
		MaxHops:          30,
		HopInterval:      100 * time.Millisecond,
		Timeout:          50 * time.Millisecond, // timeout < hopInterval → dynamic = 2
		MaxPerHop:        3,
		ParallelRequests: 10,
		ProgressThrottle: time.Millisecond,
		DstIP:            dstIP,
	}, nil, nil)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	stats := agg.Snapshot()
	for _, s := range stats {
		if s.TTL >= 1 && s.TTL <= 2 && s.Snt != 3 {
			t.Errorf("TTL %d: Snt=%d, expected 3", s.TTL, s.Snt)
		}
	}
}
